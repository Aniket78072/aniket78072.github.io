# Every file in the project

Paths below are relative to the extracted `aniket-portfolio-source` folder. Keep the directory structure intact.

## Project commands and documentation

| File | Purpose |
| --- | --- |
| `package.json` | Defines `start`, `dev`, `build`, `preview`, and `build:3d` commands. Lists optional development dependencies for rebuilding the 3D artwork. |
| `scripts/serve.mjs` | Local HTTP server using only built-in Node.js modules. Serves `public` normally, or `dist` with `--dist`. |
| `build.mjs` | Copies the website from `public` to `dist`. |
| `.gitignore` | Keeps generated folders and local logs out of a future Git repository. |
| `README.md` | Complete setup, editing, build, and troubleshooting instructions. Read this first. |
| `FILE-GUIDE.md` | This file-by-file map. |
| `SOURCE-CODE.md` | The editable text source collected under filenames for reading and copying. |
| `CREDITS.md` | Asset sources and the third-party code licence reference. |

## Pages and portfolio content

| File | Purpose |
| --- | --- |
| `public/index.html` | Main page structure, navigation, hero copy, skills, tools, contact popup and project-dialog containers. |
| `public/portfolio-data.json` | Profile/contact data plus five client entries, images, links, examples and responsibilities. Main content file to edit. |
| `public/edit.html` | Page structure and controls for the client/profile editor. |

## Stylesheets

| File | Purpose |
| --- | --- |
| `public/styles.css` | Base layouts, type, buttons, cards, dialogs and editor styles. |
| `public/enhancements.css` | Motion/depth treatments, discovery controls and additional visual components. |
| `public/refinements.css` | Client-image previews and contact-dialog refinements. |
| `public/hero.css` | Reference-inspired hero arrangement, orange semicircle, floating labels and responsive hero styling. |
| `public/theme.css` | Final shared light/orange theme across the page, cards, dialogs and editor. Start here for overall colour changes. |

The main page loads those five CSS files in the order listed. The editor loads `styles.css`, `enhancements.css`, then `theme.css`.

## JavaScript

| File | Purpose |
| --- | --- |
| `public/app.js` | Loads project data, builds cards, applies search/filters, opens project/contact dialogs and copies the email. |
| `public/data.js` | Shared JSON loading, validation, URL/image checks, text escaping and browser-draft key. |
| `public/editor.js` | Renders editable fields, adds/removes clients from drafts, handles image uploads and imports/exports JSON. |
| `public/motion.js` | Motion preferences, motion button, card tilt, scroll progress and loading the 3D scene. |
| `src/scene.js` | Editable Three.js source for the silver sculpture, lights, orbiting shapes and responsive animation. |
| `public/scene.js` | Complete prebuilt Three.js bundle consumed by the browser. Already works without `npm install`. Regenerate it using `npm run build:3d` after editing `src/scene.js`. |

`index.html` loads `app.js`. That imports `data.js` and `motion.js`; `motion.js` loads the bundled `scene.js`. `edit.html` loads `editor.js`, which uses `data.js`.

## Included assets

| File | Used for |
| --- | --- |
| `public/assets/americanportra-profile.jpg` | Nicholas G Photography client imagery. |
| `public/assets/heavy-iron-banner.jpg` | Heavy Iron portfolio creative. |
| `public/assets/bodyclique-profile.png` | BodyClique client logo. |
| `public/assets/noah-barks-profile.jpg` | Noah Barks client imagery. |
| `public/assets/lisa-kasle-profile.jpg` | Lisa Kasley Yoga client imagery. |
| `public/assets/favicon.svg` | Browser-tab icon. |
| `public/assets/three-LICENSE.txt` | Three.js MIT licence notice. Retain with the bundle. |

## Folders that commands may create

| Folder/file | Created by | Needed for normal preview? |
| --- | --- | --- |
| `dist/` | `npm run build` | No; only the built preview/publishing uses it. |
| `node_modules/` | `npm install` | No; used when rebuilding 3D source. |
| `package-lock.json` | `npm install` | Not needed to open the included bundle. Retain it if you install dependencies and start maintaining the project. |

The download excludes Git history, hosting-account configuration and temporary test files. Those are not required to run or edit the website.
