import { loadData, validateData, DRAFT_KEY, esc, safeImage } from './data.js';
let data, dirty=false;
const status=document.querySelector('#editor-status'),form=document.querySelector('#editor-form'),projectsEl=document.querySelector('#editor-projects');
function field(label,key,value,{wide=false,multiline=false,hint='',type='text'}={}) {
 return `<label class="field${wide?' wide':''}"><span>${esc(label)}</span>${multiline?`<textarea data-field="${esc(key)}">${esc(value)}</textarea>`:`<input type="${type}" data-field="${esc(key)}" value="${esc(value)}">`}${hint?`<small>${esc(hint)}</small>`:''}</label>`;
}
function projectForm(p,index) {
 return `<details class="editor-project" data-index="${index}"><summary>${esc(p.name)}</summary><div class="editor-fields">
 ${field('Client / project name','name',p.name)}${field('Industry / location','industry',p.industry)}
 ${field('Industry filter category','category',p.category)}${field('Platforms','platforms',(p.platforms||[]).join(', '),{hint:'Comma-separated, e.g. Instagram, Facebook.'})}${field('Target audience','audience',p.audience||'',{wide:true})}${field('Deliverables','deliverables',(p.deliverables||[]).join(', '),{wide:true,hint:'Comma-separated, e.g. Reel scripts, Content calendar.'})}${field('Project headline','headline',p.headline)}${field('Work types','formats',p.formats.join(', '),{hint:'Use comma-separated values: Strategy, Design, Copywriting, Reels, Community.'})}
 ${field('Short summary','summary',p.summary,{wide:true,multiline:true})}${field('Your role','role',p.role,{wide:true,multiline:true})}
 ${field('Responsibilities','responsibilities',p.responsibilities.join('\n'),{wide:true,multiline:true,hint:'One responsibility per line.'})}
 ${field('Your approach','approach',p.approach,{wide:true,multiline:true})}${field('Content example','example',p.example,{wide:true,multiline:true})}
 ${field('Example description','exampleType',p.exampleType,{hint:'For example: Reel hook from my work, or Illustrative concept.'})}
 <label class="field"><span>Preview style</span><select data-field="theme">${['clique','ascend','noah','refuge','pov','iron','eclipse','health','scholar','merge','property'].map(t=>`<option value="${t}"${p.theme===t?' selected':''}>${({clique:'Lavender',ascend:'Sage',noah:'Peach',refuge:'Forest',pov:'Slate',iron:'Blue',eclipse:'Apricot',health:'Mint',scholar:'Sky',merge:'Lilac',property:'Sand'})[t]}</option>`).join('')}</select></label>
 ${field('Instagram profile or post URL','instagram',p.instagram,{type:'url'})}${field('Client website URL','website',p.website,{type:'url'})}
 ${field('Additional examples','examples',p.examples.map(x=>`${x.label} | ${x.url}`).join('\n'),{wide:true,multiline:true,hint:'One per line: Reel example | https://www.instagram.com/reel/.../'})}
 <label class="field wide image-upload"><span>Upload a client image or work sample</span><input type="file" accept="image/jpeg,image/png,image/webp" data-upload="${index}"><small>JPG, PNG, or WebP, up to 10 MB. Added to your draft; export the file to include it in the hosted update.</small>${safeImage(p.image)?`<img class="upload-preview" src="${esc(safeImage(p.image))}" alt="Current client image or work sample">`:''}</label>
 ${field('Image URL or asset path (optional)','image',p.image,{hint:'An upload fills this field automatically. Clear it to use a designed text card.'})}${field('Image description','imageLabel',p.imageLabel)}
 <label class="field"><span>Image use</span><select data-field="imageKind"><option value="work"${p.imageKind!=='client'?' selected':''}>My work sample</option><option value="client"${p.imageKind==='client'?' selected':''}>Client profile photo / brand image</option></select></label>
 <label class="field"><span>Client image layout</span><select data-field="imageFit"><option value="cover"${p.imageFit!=='contain'?' selected':''}>Photo · fill the preview</option><option value="contain"${p.imageFit==='contain'?' selected':''}>Logo · show the whole image</option></select></label>
 <label class="field"><span>Photo focus</span><select data-field="imagePosition">${['top','center','bottom'].map(value=>`<option value="${value}"${(p.imagePosition||'center')===value?' selected':''}>${value[0].toUpperCase()+value.slice(1)}</option>`).join('')}</select><small>Applies to client photo previews.</small></label>
 ${field('Image source URL (optional)','imageSource',p.imageSource||'',{type:'url',hint:'For client photos or logos, link to the public source.'})}
 <button type="button" class="editor-remove" data-remove="${index}">Remove project from draft</button></div></details>`;
}
function render(openIndex=null) {
 document.querySelector('#profile-fields').innerHTML=field('Name','name',data.profile.name)+field('Location','location',data.profile.location)+field('Contact email','email',data.profile.email,{type:'email'})+field('LinkedIn URL (optional)','linkedin',data.profile.linkedin,{type:'url'})+field('Profile introduction','bio',data.profile.bio,{wide:true,multiline:true});
 projectsEl.innerHTML=data.projects.map(projectForm).join('');
 if(openIndex!==null) projectsEl.querySelector(`[data-index="${openIndex}"]`)?.setAttribute('open','');
}
function collect() {
 const result=structuredClone(data);
 document.querySelectorAll('#profile-fields [data-field]').forEach(el=>result.profile[el.dataset.field]=el.value.trim());
 projectsEl.querySelectorAll('[data-index]').forEach(panel=>{
 const p=result.projects[Number(panel.dataset.index)];
 panel.querySelectorAll('[data-field]').forEach(el=>{
 const key=el.dataset.field,value=el.value.trim();
 if(['formats','platforms','deliverables'].includes(key))p[key]=value.split(',').map(x=>x.trim()).filter(Boolean);
 else if(key==='responsibilities')p[key]=value.split('\n').map(x=>x.trim()).filter(Boolean);
 else if(key==='examples')p[key]=value.split('\n').filter(x=>x.trim()).map(line=>{const i=line.indexOf('|');if(i<0)throw new Error(`${p.name}: write example links as Label | https://...`);return {label:line.slice(0,i).trim(),url:line.slice(i+1).trim()}});
 else p[key]=value;
 });
 });
 return validateData(result);
}
function save() {
 data=collect();try{localStorage.setItem(DRAFT_KEY,JSON.stringify(data));}catch{throw new Error('This draft is too large for browser storage. Use fewer or smaller uploaded images.');}dirty=false;return data;
}
function showError(error){status.textContent=error.message;status.style.color='var(--error)';status.scrollIntoView({block:'nearest'});}
function notice(text){status.textContent=text;status.style.color='';}
form.addEventListener('submit',e=>e.preventDefault());
form.addEventListener('input',()=>{dirty=true;notice('Unsaved changes. Save a draft to preview them.');});
document.querySelector('#save-draft').addEventListener('click',()=>{try{save();notice('Draft saved on this browser. Open Preview saved draft to review it.');}catch(error){showError(error)}});
document.querySelector('#export-data').addEventListener('click',()=>{try{const output=save();const blob=new Blob([JSON.stringify(output,null,2)+'\n'],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='portfolio-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Exported portfolio-data.json. Share it in this conversation to update the hosted portfolio.');}catch(error){showError(error)}});
document.querySelector('#add-project').addEventListener('click',()=>{try{data=collect();data.projects.push({id:crypto.randomUUID(),name:'New client',industry:'Your industry',category:'',platforms:[],audience:'',deliverables:[],formats:['Design'],theme:'clique',headline:'Your next story.',summary:'',role:'',responsibilities:[],approach:'',exampleType:'Portfolio content example',example:'',image:'',imageLabel:'',instagram:'',website:'',examples:[]});render(data.projects.length-1);dirty=true;projectsEl.lastElementChild.scrollIntoView({behavior:'smooth',block:'start'});notice('New project added. Fill in the details and save your draft.');}catch(error){showError(error)}});
projectsEl.addEventListener('click',e=>{const button=e.target.closest('[data-remove]');if(!button)return;try{data=collect();const index=Number(button.dataset.remove);const name=data.projects[index].name;data.projects.splice(index,1);render();dirty=true;notice(`${name} removed from the unsaved draft. Hosted projects are unchanged.`);}catch(error){showError(error)}});
document.querySelector('#import-data').addEventListener('click',()=>document.querySelector('#import-file').click());
document.querySelector('#import-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>10_000_000)throw new Error('Choose a JSON data file smaller than 10 MB.');data=validateData(JSON.parse(await file.text()));render();dirty=true;notice('Data imported. Review the changes, then save your draft.');}catch(error){showError(error)}e.target.value='';});
document.querySelector('#restore-data').addEventListener('click',async()=>{try{if(!confirm('Discard the local draft and load the hosted portfolio data?'))return;localStorage.removeItem(DRAFT_KEY);data=await loadData(false);render();dirty=false;notice('Hosted portfolio data restored.');}catch(error){showError(error)}});
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
try{data=await loadData(true);render();document.querySelectorAll('button[disabled]').forEach(b=>b.disabled=false);notice(localStorage.getItem(DRAFT_KEY)?'Editing your saved local draft. Discard it to reload the latest hosted client list.':'Ready to edit. Save a draft before opening the preview.');}catch(error){showError(error)}

projectsEl.addEventListener('change',async e=>{
 const input=e.target.closest('[data-upload]');if(!input||!input.files[0])return;
 const file=input.files[0];
 try{
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Choose a JPG, PNG, or WebP image.');
  if(file.size>10000000)throw new Error('Choose an image smaller than 10 MB.');
  const bitmap=await createImageBitmap(file),ratio=Math.min(1,1200/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);
  const ctx=canvas.getContext('2d');ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  const image=canvas.toDataURL('image/webp',.85);if(!safeImage(image))throw new Error('This image is too large. Please choose a smaller image.');
  const panel=input.closest('[data-index]');panel.querySelector('[data-field="image"]').value=image;
  const description=panel.querySelector('[data-field="imageLabel"]');if(!description.value)description.value='Uploaded portfolio work sample';
  let preview=panel.querySelector('.upload-preview');if(!preview){preview=document.createElement('img');preview.className='upload-preview';preview.alt='Current client image or work sample';input.parentNode.append(preview);}preview.src=image;
  dirty=true;notice('Image added to your draft. Save and preview it, then export when ready.');
 }catch(error){showError(error)}input.value='';
});
