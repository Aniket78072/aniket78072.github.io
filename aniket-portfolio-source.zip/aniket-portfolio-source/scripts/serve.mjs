import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

// A local preview server. Uses only built-in Node.js modules.
const args = process.argv.slice(2);
const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const folder = args.includes('--dist') ? 'dist' : 'public';
const root = resolve(projectRoot, folder);
const portFlag = args.indexOf('--port');
const port = Number(portFlag >= 0 ? args[portFlag + 1] : process.env.PORT || 4173);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('Choose a port between 1 and 65535, for example: npm start -- --port 4175');
  process.exit(1);
}

try {
  await readFile(resolve(root, 'index.html'));
} catch {
  console.error(folder === 'dist' ? 'Run npm run build before npm run preview.' : 'The public/index.html file is missing. Extract the complete ZIP first.');
  process.exit(1);
}

const types = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};

const server = createServer(async (request, response) => {
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  if (!['GET', 'HEAD'].includes(request.method)) {
    response.writeHead(405, { Allow: 'GET, HEAD' });
    response.end('Method not allowed');
    return;
  }
  let file;
  try {
    const url = new URL(request.url, 'http://localhost');
    const pathname = decodeURIComponent(url.pathname);
    if (pathname.includes('\0') || pathname.includes('\\')) throw new Error('Invalid path');
    file = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
    if (!file.startsWith(root + sep)) throw new Error('Invalid path');
  } catch {
    response.writeHead(400);
    response.end('Invalid path');
    return;
  }
  try {
    const body = await readFile(file);
    response.writeHead(200, {
      'Content-Type': types[extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': body.length
    });
    response.end(request.method === 'HEAD' ? undefined : body);
  } catch (error) {
    response.writeHead(['ENOENT', 'EISDIR', 'ENOTDIR'].includes(error.code) ? 404 : 500);
    response.end('File not found');
  }
});

server.on('error', error => {
  console.error(error.code === 'EADDRINUSE'
    ? `Port ${port} is busy. Try: npm start -- --port ${port + 1}`
    : error.message);
  process.exit(1);
});

server.listen(port, '127.0.0.1', () => {
  console.log(`\nAniket's portfolio is running from ${folder}/`);
  console.log(`Portfolio: http://localhost:${port}`);
  console.log(`Client editor: http://localhost:${port}/edit.html`);
  console.log('Save a file, then refresh your browser to see changes.');
  console.log('Press Ctrl+C to stop the server.\n');
});
