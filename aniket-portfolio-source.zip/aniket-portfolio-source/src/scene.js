import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

// Decorative, self-contained 3D. The portfolio stays usable without WebGL.
export function mountScene(host, motion) {
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' }); }
  catch { host.dataset.render = 'fallback'; return; }
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
  renderer.setClearColor(0x000000, 0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.35;
  renderer.domElement.setAttribute('aria-hidden', 'true');
  host.append(renderer.domElement);
  host.dataset.render = 'webgl';

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, .1, 30);
  camera.position.set(0, 0, 6.6);
  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room, .04);
  scene.environment = environment.texture;
  room.dispose(); pmrem.dispose();

  const group = new THREE.Group(); scene.add(group);
  const metal = new THREE.MeshPhysicalMaterial({ color: 0xd8d3ce, metalness: .88, roughness: .23, clearcoat: 1, clearcoatRoughness: .14, iridescence: .08, iridescenceIOR: 1.35, envMapIntensity: 1.8 });
  const knot = new THREE.Mesh(new THREE.TorusKnotGeometry(.86, .265, 176, 28, 2, 3), metal);
  knot.rotation.set(.34, -.4, -.45);
  knot.position.set(.25, .2, -.1);
  knot.scale.setScalar(1.17); group.add(knot);

  const pearl = new THREE.Mesh(new THREE.SphereGeometry(.22, 32, 24), new THREE.MeshPhysicalMaterial({color:0xff944d,metalness:.4,roughness:.12,clearcoat:1,envMapIntensity:1.7}));
  pearl.position.set(-1.32, 1.1, .1); group.add(pearl);
  const satellite = new THREE.Mesh(new THREE.IcosahedronGeometry(.26, 0), new THREE.MeshPhysicalMaterial({color:0xefebe4,metalness:.78,roughness:.19,envMapIntensity:2}));
  satellite.position.set(1.37, -1.35, .2); group.add(satellite);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.85,.008,8,140), new THREE.MeshBasicMaterial({color:0x37302b,transparent:true,opacity:.16}));
  ring.rotation.set(.7,.3,-.6);ring.position.z=-.5;group.add(ring);
  scene.add(new THREE.AmbientLight(0xffead7,.9));
  const light=new THREE.DirectionalLight(0xffffff,4);light.position.set(3,4,5);scene.add(light);
  const fill=new THREE.DirectionalLight(0xffac70,3);fill.position.set(-4,-2,2);scene.add(fill);

  let visible=true, frame=0, last=0, elapsed=0, targetX=0, targetY=0;
  function render() {renderer.render(scene,camera);}
  function resize() {const {width,height}=host.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();render();}
  function loop(now) {
    frame=0;
    if(!motion.enabled||!visible||document.hidden)return;
    if(now-last>32) {
      const delta=Math.min((now-last)/1000,.05);last=now;elapsed+=delta;
      knot.rotation.y=-.4+elapsed*.09;
      knot.position.y=.2+Math.sin(elapsed*.55)*.08;
      pearl.position.y=1.1+Math.sin(elapsed*.8)*.1;
      satellite.rotation.y=elapsed*.25;satellite.rotation.z=elapsed*.12;
      group.rotation.x+=(targetY-group.rotation.x)*.06;
      group.rotation.y+=(targetX-group.rotation.y)*.06;
      render();
    }
    frame=requestAnimationFrame(loop);
  }
  function sync() {cancelAnimationFrame(frame);frame=0;last=performance.now();if(motion.enabled&&visible&&!document.hidden)frame=requestAnimationFrame(loop);else render();}
  const region=host.closest('.hero-art');
  region.addEventListener('pointermove',e=>{if(!motion.enabled||e.pointerType==='touch')return;const r=region.getBoundingClientRect();targetX=((e.clientX-r.left)/r.width-.5)*.4;targetY=((e.clientY-r.top)/r.height-.5)*.25;});
  region.addEventListener('pointerleave',()=>{targetX=targetY=0;});
  window.addEventListener('portfolio-motion',sync);
  document.addEventListener('visibilitychange',sync);
  const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();});observer.observe(host);
  const sizing=new ResizeObserver(resize);sizing.observe(host);
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(frame);host.dataset.render='fallback';});
  resize();sync();
}
