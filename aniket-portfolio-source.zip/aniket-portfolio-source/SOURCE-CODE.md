# Complete authored source, by filename

The actual files are included separately in this ZIP. Read README.md first for running and editing instructions.

This reading copy includes every editable code file. The generated 553 KB public/scene.js bundle, five binary client images, and Three.js licence are included as separate files; the editable 3D source is included below. Edit the actual files, not this reading copy, to change the website.

## package.json

```json
{
  "name": "aniket-creative-portfolio",
  "version": "6.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "start": "node scripts/serve.mjs",
    "dev": "node scripts/serve.mjs",
    "build": "node build.mjs",
    "preview": "node scripts/serve.mjs --dist",
    "build:3d": "esbuild src/scene.js --bundle --minify --format=esm --legal-comments=eof --outfile=public/scene.js"
  },
  "devDependencies": {
    "three": "0.186.0",
    "esbuild": "0.28.2"
  },
  "engines": {
    "node": ">=22"
  }
}
```

## scripts/serve.mjs

```javascript
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

// A local preview server. Uses only built-in Node.js modules.
const args = process.argv.slice(2);
const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const folder = args.includes('--dist') ? 'dist' : 'public';
const root = resolve(projectRoot, folder);
const portFlag = args.indexOf('--port');
const port = Number(portFlag >= 0 ? args[portFlag + 1] : process.env.PORT || 4173);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('Choose a port between 1 and 65535, for example: npm start -- --port 4175');
  process.exit(1);
}

try {
  await readFile(resolve(root, 'index.html'));
} catch {
  console.error(folder === 'dist' ? 'Run npm run build before npm run preview.' : 'The public/index.html file is missing. Extract the complete ZIP first.');
  process.exit(1);
}

const types = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};

const server = createServer(async (request, response) => {
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  if (!['GET', 'HEAD'].includes(request.method)) {
    response.writeHead(405, { Allow: 'GET, HEAD' });
    response.end('Method not allowed');
    return;
  }
  let file;
  try {
    const url = new URL(request.url, 'http://localhost');
    const pathname = decodeURIComponent(url.pathname);
    if (pathname.includes('\0') || pathname.includes('\\')) throw new Error('Invalid path');
    file = resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
    if (!file.startsWith(root + sep)) throw new Error('Invalid path');
  } catch {
    response.writeHead(400);
    response.end('Invalid path');
    return;
  }
  try {
    const body = await readFile(file);
    response.writeHead(200, {
      'Content-Type': types[extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': body.length
    });
    response.end(request.method === 'HEAD' ? undefined : body);
  } catch (error) {
    response.writeHead(['ENOENT', 'EISDIR', 'ENOTDIR'].includes(error.code) ? 404 : 500);
    response.end('File not found');
  }
});

server.on('error', error => {
  console.error(error.code === 'EADDRINUSE'
    ? `Port ${port} is busy. Try: npm start -- --port ${port + 1}`
    : error.message);
  process.exit(1);
});

server.listen(port, '127.0.0.1', () => {
  console.log(`\nAniket's portfolio is running from ${folder}/`);
  console.log(`Portfolio: http://localhost:${port}`);
  console.log(`Client editor: http://localhost:${port}/edit.html`);
  console.log('Save a file, then refresh your browser to see changes.');
  console.log('Press Ctrl+C to stop the server.\n');
});
```

## build.mjs

```javascript
import { cp, mkdir } from 'node:fs/promises';
await mkdir('dist', { recursive: true });
await cp('public', 'dist', { recursive: true });
console.log('Static portfolio ready in dist/');
```

## .gitignore

```text
node_modules/
dist/
.DS_Store
*.log
```

## public/index.html

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Aniket — Social Media & Creative Portfolio</title>
  <meta name="description" content="Selected social media, content writing, and design work by Aniket. Explore client projects, content examples, and an approach built around thoughtful strategy and clear storytelling.">
  <meta name="robots" content="noindex,nofollow">
  <meta property="og:url" content="https://aniket-creative-portfolio.eleven7809.chatgpt.site"><meta property="og:type" content="website"><meta property="og:title" content="Aniket — Social Media, Words & Design"><meta property="og:description" content="Social media strategy, content writing, and design. Explore selected client work.">
  <meta name="theme-color" content="#fafaf8"><link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="styles.css"><link rel="stylesheet" href="enhancements.css"><link rel="stylesheet" href="refinements.css"><link rel="stylesheet" href="hero.css"><link rel="stylesheet" href="theme.css"><script src="app.js" type="module"></script>
</head>
<body class="portfolio-page">
  <div id="scroll-progress" aria-hidden="true"></div>
  <a class="skip-link" href="#work">Skip to selected work</a>
  <div class="draft-banner" id="draft-banner" hidden>Local draft preview · only on this browser <a href="edit.html">Back to editor ↗</a></div>
  <header class="site-header"><div class="container nav-wrap">
    <a href="#profile" class="wordmark" aria-label="Aniket, back to top">aniket<span>✳</span></a>
    <nav aria-label="Main navigation"><a href="#work">Selected work</a><a href="#approach">About & skills</a><button type="button" class="nav-contact" data-contact aria-haspopup="dialog" aria-controls="contact-dialog">Let’s talk <span aria-hidden="true">↗</span></button></nav>
  </div></header>
  <main>
    <section id="profile" class="reference-hero" aria-labelledby="hero-heading">
      <div class="hero-heading-wrap container">
        <span class="hello-tag">Hello there! <svg viewBox="0 0 36 36" aria-hidden="true"><path d="M9 27 3 32M15 20 13 6M21 23 33 16"/></svg></span>
        <h1 id="hero-heading">I’m <span data-name>Aniket</span><span class="hero-wave" aria-hidden="true">✳</span></h1>
        <p class="hero-role">A Social Media Executive <span>& Creative.</span></p>
        <svg class="hero-spark" viewBox="0 0 62 62" aria-hidden="true"><path d="M29 32 8 39M34 38 29 59M23 24 3 24M39 25 49 7"/></svg>
      </div>
      <div class="hero-composition hero-art container">
        <div class="hero-arc" aria-hidden="true"></div>
        <div id="scene-host" aria-hidden="true"><div class="scene-fallback"></div></div>
        <aside class="hero-statement"><span class="statement-mark" aria-hidden="true">✳</span><p>Good content gets noticed.<br><strong>Great content connects.</strong></p><p class="statement-detail">I bring together strategy, words, and design to tell stories that feel like your brand.</p></aside>
        <aside class="hero-experience"><strong>1 year</strong><p>of hands-on experience<br>in social media & content</p><span>Based in India · Open to opportunities</span></aside>
        <div class="hero-skills" aria-label="My creative skills"><span class="hero-skill skill-social"><span aria-hidden="true">↗</span> Social media</span><span class="hero-skill skill-copy"><span aria-hidden="true">✦</span> Copywriting</span><span class="hero-skill skill-design"><span aria-hidden="true">✳</span> Design</span><span class="hero-skill skill-strategy"><span aria-hidden="true">↗</span> Strategy</span></div>
        <div class="hero-action-pill"><a href="#work">Portfolio <span aria-hidden="true">↗</span></a><button type="button" data-contact aria-haspopup="dialog" aria-controls="contact-dialog">Let’s talk</button></div>
        <button id="motion-toggle" class="motion-toggle" aria-pressed="true">Ⅱ Motion on</button>
      </div>
    </section>
    <div class="client-ribbon container"><p>SELECTED CLIENTS</p><div id="client-ribbon" aria-label="Featured client projects"></div></div>
    <section id="work" class="work-section container" aria-labelledby="work-heading">
      <div class="section-heading"><div><p class="eyebrow">01 / SELECTED WORK · <span id="client-total">5</span> CLIENTS</p><h2 id="work-heading">Different brands.<br><span>One thoughtful approach.</span></h2></div><p>From heavy equipment to wellness,<br>content shaped around the people<br>each brand wants to reach.</p></div>
      <div class="work-controls"><div class="filter-buttons" role="group" aria-label="Filter by work type"><button class="filter active" data-filter="All" aria-pressed="true">All work <span id="total-count">05</span></button><button class="filter" data-filter="Strategy" aria-pressed="false">Strategy</button><button class="filter" data-filter="Design" aria-pressed="false">Design</button><button class="filter" data-filter="Copywriting" aria-pressed="false">Copywriting</button><button class="filter" data-filter="Reels" aria-pressed="false">Reels</button></div><label class="client-filter"><span class="sr-only">Filter by client</span><select id="client-select"><option value="">All clients</option></select></label></div>
      <div class="discovery-row"><label class="project-search"><span aria-hidden="true">⌕</span><input id="project-search" type="search" placeholder="Search clients, industries, or services…" aria-label="Search client projects"></label><label class="industry-filter"><span class="sr-only">Filter by industry</span><select id="category-select"><option value="">All industries</option></select></label><a href="edit.html#client-editor" class="edit-clients-link">Manage client details ↗</a></div>
      <div class="work-meta"><span id="result-count" aria-live="polite">Loading projects…</span><span>SELECT A PROJECT TO EXPLORE ↗</span></div>
      <div id="project-grid" class="project-grid"></div>
      <div id="empty-state" class="empty-state" hidden><h3>No projects in this view.</h3><p>Try another work type or reset the filters.</p><button id="reset-filters" class="button secondary">Show all work ↗</button></div>
      <div class="work-more"><button id="show-more" class="button secondary" hidden>Show more projects ↓</button></div>
      <p class="work-disclaimer">Project tiles are portfolio presentations. Open each project for original work samples, copy, responsibilities, and available client links.</p>
    </section>
    <section id="approach" class="about-section container" aria-labelledby="about-heading">
      <div class="section-heading"><div><p class="eyebrow">02 / THE PERSON BEHIND THE POSTS</p><h2 id="about-heading">A creative eye.<br><span>A hands-on mindset.</span></h2></div><p>I care about the details that make<br>content feel like the brand — and<br>the process that gets it delivered.</p></div>
      <div class="about-grid"><div class="profile-panel"><div class="monogram" aria-hidden="true">a<span>✳</span></div><p class="eyebrow">HELLO, I’M <span data-name>ANIKET</span></p><h3>Strategy to the<br>last caption.</h3><p data-bio>I turn brand goals into content people want to spend time with. My work brings together social media planning, thoughtful copy, visual direction, and day-to-day community engagement.</p><div class="experience"><span>PROFESSIONAL EXPERIENCE</span><strong>Social Media Executive</strong><p>Esferasoft · Multi-client social media</p></div><div class="education"><span>EDUCATION</span><p>B.Tech · Completed 2025<br>Rayat Bahra Institute of Engineering<br>and Nano-Technology</p></div></div>
      <div class="capability-panel"><div class="capability-row"><span class="row-number">01</span><div><h3>Plan with purpose</h3><p>Content strategy, calendars, audience research, trend research, and platform-specific planning.</p><div class="skill-tags"><span>Instagram</span><span>Facebook</span><span>LinkedIn</span><span>X</span></div></div></div><div class="capability-row"><span class="row-number">02</span><div><h3>Make the message count</h3><p>SEO-friendly captions, banner copy, carousel hooks, Reel scripts, visual concepts, and consistent brand messaging.</p><div class="skill-tags"><span>Copywriting</span><span>Creative direction</span><span>Short-form video</span></div></div></div><div class="capability-row"><span class="row-number">03</span><div><h3>Keep the work moving</h3><p>Community engagement, creative coordination, content delivery, performance reporting, and basic Meta Ads setup and monitoring.</p><div class="skill-tags"><span>Organic engagement</span><span>Reporting</span><span>Meta Ads · working knowledge</span></div></div></div><div class="tools-block"><p class="eyebrow">TOOLS IN MY WORKFLOW</p><div class="tool-list"><span>Meta Business Suite</span><span>Meta Ads Manager</span><span>Google Sheets</span><span>Google Docs</span><span>ChatGPT</span></div><p>For publishing, campaign monitoring, planning, reporting, and creative ideation.</p></div></div></div>
      <div class="contact-panel"><div><p class="eyebrow">LET’S MAKE SOMETHING THAT CONNECTS.</p><h2>Your next brand story<br>could start here<span>.</span></h2></div><button type="button" class="button primary" data-contact aria-haspopup="dialog" aria-controls="contact-dialog">Let’s talk <span aria-hidden="true">↗</span></button></div>
    </section>
  </main>
  <footer class="container footer"><a class="wordmark" href="#profile">aniket<span>✳</span></a><p>Strategy. Words. Visuals. Made with intent.</p><div><a id="linkedin-link" hidden target="_blank" rel="noopener noreferrer">LinkedIn ↗</a><a href="edit.html">Edit portfolio</a><a href="#profile">Back to top ↑</a></div></footer>
  <dialog id="project-dialog" aria-labelledby="dialog-title"><button class="dialog-close" aria-label="Close project">×</button><div id="dialog-content"></div></dialog>
  <dialog id="contact-dialog" aria-labelledby="contact-title" aria-describedby="contact-description"><button class="dialog-close" aria-label="Close contact">×</button><div class="contact-dialog-content"><p class="eyebrow">A GOOD CONVERSATION STARTS HERE</p><h2 id="contact-title">Let’s talk<span>.</span></h2><p id="contact-description">Have a role or project in mind? Reach me at:</p><a class="contact-email" id="contact-email" data-email href="mailto:aniketpathania68393@gmail.com">aniketpathania68393@gmail.com</a><div class="contact-actions"><button type="button" class="button primary" id="copy-email">Copy email <span aria-hidden="true">↗</span></button><a class="button secondary" data-email href="mailto:aniketpathania68393@gmail.com">Open email app ↗</a></div><p id="copy-status" role="status" aria-live="polite"></p></div></dialog>
  <noscript><div class="container">Enable JavaScript to explore project filters and work samples. You can still contact Aniket at aniketpathania68393@gmail.com.</div></noscript>
</body></html>
```

## public/portfolio-data.json

```json
{
  "profile": {
    "name": "Aniket",
    "role": "Social Media Executive · Content writer · Designer",
    "email": "aniketpathania68393@gmail.com",
    "location": "Himachal Pradesh, India",
    "linkedin": "",
    "bio": "I turn brand goals into content people want to spend time with. My work brings together social media planning, thoughtful copy, visual direction, and day-to-day community engagement."
  },
  "projects": [
    {
      "id": "photography",
      "name": "Nicholas G Photography",
      "industry": "Photography · California, USA",
      "category": "Photography",
      "formats": [
        "Design",
        "Copywriting",
        "Reels"
      ],
      "theme": "pov",
      "headline": "Through a different lens.",
      "summary": "POV Reel concepts that connect the creative process to the finished photograph.",
      "role": "Reel scripting, cover direction, and behind-the-scenes storytelling.",
      "responsibilities": [
        "Shape Meta Glasses footage into a clear beginning, middle, and payoff.",
        "Plan the transition from a photographer’s point of view to the final image.",
        "Create concise cover and story concepts aligned with the visual grid."
      ],
      "approach": "Use the real process as the story: preparation, location, the moment, and the image it creates.",
      "exampleType": "Reel sequence from my work",
      "example": "Get ready → gear check → arrive on location → photographer POV → reveal the final images.",
      "image": "assets/americanportra-profile.jpg",
      "imageLabel": "Nick and Rosie of American Portra, from the client website",
      "instagram": "https://www.instagram.com/americanportra/",
      "website": "https://nicholasgphotography.com/",
      "examples": [
        {
          "label": "Client Facebook page",
          "url": "https://www.facebook.com/nicholasgphoto/"
        }
      ],
      "platforms": [
        "Instagram",
        "Facebook"
      ],
      "audience": "Couples and personal brands looking for authentic, editorial photography.",
      "deliverables": [
        "POV Reels",
        "Carousel hooks",
        "Reel covers",
        "Story concepts"
      ],
      "imageKind": "client",
      "imageFit": "cover",
      "imagePosition": "top",
      "imageSource": "https://www.nicholasgphotography.com/"
    },
    {
      "id": "heavy-iron",
      "name": "Heavy Iron Inc.",
      "industry": "Heavy equipment · Alberta, Canada",
      "category": "Heavy equipment",
      "formats": [
        "Strategy",
        "Design",
        "Copywriting",
        "Reels"
      ],
      "theme": "iron",
      "headline": "Built for the job.",
      "summary": "Turning equipment and contractor needs into clear, useful social content.",
      "role": "Content planning, banner concepts, SEO captions, Reel scripts, and weekly reporting.",
      "responsibilities": [
        "Plan service-led and machine-specific content for Instagram, Facebook, and X.",
        "Write concise hooks and captions that connect equipment to real site needs.",
        "Coordinate creative revisions and track weekly content performance."
      ],
      "approach": "Start with a contractor problem, show relevant equipment, and finish with one clear next step.",
      "exampleType": "Banner copy from my work",
      "example": "Breakdown On Site?\nOur mobile mechanics come to you.\nLess downtime. More productivity.",
      "image": "assets/heavy-iron-banner.jpg",
      "imageLabel": "Existing carousel creative · portfolio sample",
      "instagram": "",
      "website": "https://heavyironinc.com/",
      "examples": [],
      "platforms": [
        "Instagram",
        "Facebook",
        "X"
      ],
      "audience": "Contractors, excavation companies, operators, and project managers.",
      "deliverables": [
        "Content calendars",
        "Machine-specific banners",
        "Reel scripts",
        "SEO captions",
        "Weekly reporting"
      ]
    },
    {
      "id": "bodyclique",
      "name": "BodyClique",
      "industry": "Wellness · Creator community",
      "category": "Wellness",
      "formats": [
        "Strategy",
        "Copywriting",
        "Reels"
      ],
      "theme": "clique",
      "headline": "You belong here.",
      "summary": "Community-first storytelling for a wellness and body-confidence platform.",
      "role": "Instagram strategy, creator-focused content, Reel concepts, and visual direction.",
      "responsibilities": [
        "Build content around body confidence, wellness, and creator journeys.",
        "Develop Reel hooks and scripts with an authentic community voice.",
        "Plan audience engagement and consistent visual messaging."
      ],
      "approach": "Lead with belonging and real journeys so the message feels welcoming, inclusive, and human.",
      "exampleType": "Reel hook from my work",
      "example": "Just because you fit in…\ndoesn’t mean you belong.",
      "image": "assets/bodyclique-profile.png",
      "imageLabel": "BodyClique brand logo from the client website",
      "instagram": "https://www.instagram.com/_bodyclique_/",
      "website": "https://bodyclique.com/home/",
      "examples": [],
      "platforms": [
        "Instagram",
        "Facebook"
      ],
      "audience": "Wellness creators, fitness coaches, and people sharing body-confidence journeys.",
      "deliverables": [
        "Community messaging",
        "Reel concepts",
        "Creator-focused content",
        "Visual direction"
      ],
      "imageKind": "client",
      "imageFit": "contain",
      "imagePosition": "center",
      "imageSource": "https://bodyclique.com/"
    },
    {
      "id": "noah-barks",
      "name": "Noah Barks",
      "industry": "Pet sitting · Pet care",
      "category": "Pet care",
      "formats": [
        "Design",
        "Copywriting"
      ],
      "theme": "noah",
      "headline": "Home. Happy. Cared for.",
      "summary": "Warm, trust-led static content for people who treat pets like family.",
      "role": "Static banner concepts, Instagram and Facebook copy, and SEO-friendly captions.",
      "responsibilities": [
        "Create static content around care, reassurance, and practical pet topics.",
        "Keep headlines short and visual direction simple.",
        "Write captions with relevant search terms and clear next steps."
      ],
      "approach": "Put the owner’s peace of mind first. Keep each static creative focused on one clear message.",
      "exampleType": "Static-post headline from my work",
      "example": "They stay home.\nYou stay worry-free.",
      "image": "assets/noah-barks-profile.jpg",
      "imageLabel": "Dog photograph from the Noah Barks client website",
      "instagram": "https://www.instagram.com/noah.barks/",
      "website": "https://noahbarks.com/",
      "examples": [],
      "platforms": [
        "Instagram",
        "Facebook"
      ],
      "audience": "Pet owners looking for dependable, reassuring care.",
      "deliverables": [
        "Static posts",
        "Pet-care topics",
        "Banner copy",
        "SEO captions"
      ],
      "imageKind": "client",
      "imageFit": "cover",
      "imagePosition": "center",
      "imageSource": "https://noahbarks.com/"
    },
    {
      "id": "lisa-kasley-yoga",
      "name": "Lisa Kasley Yoga",
      "industry": "Yoga · Wellness",
      "category": "Wellness",
      "formats": [],
      "theme": "health",
      "headline": "A moment of balance.",
      "summary": "Yoga & wellness. Project details and work samples coming soon.",
      "role": "",
      "responsibilities": [],
      "approach": "",
      "exampleType": "",
      "example": "",
      "image": "assets/lisa-kasle-profile.jpg",
      "imageLabel": "Lisa Kasle practising yoga outdoors, from the client website",
      "instagram": "https://www.instagram.com/lisakasleyoga/",
      "website": "https://www.lisakasleyoga.com/",
      "examples": [],
      "platforms": [],
      "audience": "",
      "deliverables": [],
      "imageKind": "client",
      "imageFit": "cover",
      "imagePosition": "center",
      "imageSource": "https://www.lisakasleyoga.com/"
    }
  ]
}
```

## public/styles.css

```css
:root{--bg:#111113;--panel:#1a1a1e;--text:#f2f0ea;--muted:#aaa9b1;--purple:#b9a4ff;--line:#323136;--font:Arial,Helvetica,sans-serif;color-scheme:dark}*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:100px}body{margin:0;background:var(--bg);color:var(--text);font-family:var(--font);-webkit-font-smoothing:antialiased}body:has(dialog[open]){overflow:hidden}a{color:inherit;text-decoration:none}button,input,select,textarea{font:inherit}button,a,select{touch-action:manipulation}button{cursor:pointer}button:disabled{cursor:wait;opacity:.55}button,input,select,textarea{color:inherit}button{background:none}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:2px solid var(--purple);outline-offset:5px}h1,h2,h3,p{margin:0}img{display:block;max-width:100%}[hidden]{display:none!important}.container{width:min(1240px,calc(100% - 96px));margin-inline:auto}.eyebrow{font-size:10px;font-weight:700;letter-spacing:1.9px;line-height:1.6}.site-header{position:sticky;top:0;z-index:20;background:#111113ed;backdrop-filter:blur(16px);border-bottom:1px solid var(--line)}.nav-wrap{height:86px;display:flex;align-items:center;justify-content:space-between}.wordmark{font-size:30px;font-weight:800;letter-spacing:-1.7px}.wordmark span{font-size:17px;vertical-align:top;color:var(--purple);margin-left:3px}nav{display:flex;align-items:center;gap:37px;font-size:12px}nav>a{transition:color .2s}nav>a:hover{color:var(--purple)}.nav-contact{border:1px solid #68646e;border-radius:999px;padding:12px 18px}.nav-contact span{margin-left:17px}.hero{padding-top:58px}.hero-grid{display:grid;grid-template-columns:1fr 1fr;gap:26px;align-items:center}.hero-copy{padding-bottom:34px}.hero-copy>.eyebrow{display:flex;gap:9px;align-items:center;color:#ceccd2}.status-dot{width:6px;height:6px;border-radius:50%;background:var(--purple);box-shadow:0 0 0 4px #b9a4ff12}h1{font-size:clamp(58px,5.65vw,79px);font-weight:500;line-height:1.02;letter-spacing:-4.2px;margin:28px 0 25px}h1>span{color:var(--purple)}.hero-intro{font-size:17px;line-height:1.5;letter-spacing:-.3px}.hero-intro strong{font-weight:600}.hero-description{font-size:14px;color:var(--muted);line-height:1.7;margin-top:10px}.button{border-radius:999px;padding:16px 24px;font-size:12px;font-weight:700;display:inline-flex;gap:35px;align-items:center;justify-content:center;border:1px solid transparent;transition:transform .2s,background .2s}.button:hover{transform:translateY(-2px)}.primary{background:var(--purple);color:#191320}.primary:hover{background:#c7b7ff}.secondary{border-color:#65616d;color:var(--text)}.hero-copy>.button{margin-top:28px}.button>span{font-size:19px;line-height:.8}.hero-location{display:flex;align-items:center;gap:9px;flex-wrap:wrap;font-size:10px;color:#adabb4;margin-top:23px}.hero-location>span:first-child{font-size:20px;color:var(--purple)}.location-line{width:17px;height:1px;background:#68636e}.hero-art{position:relative;min-height:606px;isolation:isolate;overflow:clip;overflow-clip-margin:16px}.orbit{position:absolute;border:1px solid #39343f;border-radius:50%;z-index:-1;pointer-events:none}.orbit-one{width:450px;height:450px;left:5%;top:95px}.orbit-two{width:390px;height:520px;left:12%;top:62px;transform:rotate(35deg);border-color:#302b38}.art-star{position:absolute;font-size:92px;color:var(--purple);top:5px;right:8px;line-height:1}.art-label{font-size:8px;letter-spacing:1.4px;position:absolute;top:27px;left:8px;color:#a39cac;display:flex;gap:8px;align-items:center}.tiny-cross{font-size:21px}.mini-card{overflow:hidden;position:absolute;border:1px solid #ffffff25;border-radius:8px;box-shadow:0 30px 55px #0007}.equipment-card{width:238px;left:0;top:170px;transform:rotate(-11deg);background:#1b1c22}.equipment-card>img{width:100%;height:280px;object-fit:cover;object-position:top}.mini-caption{display:flex;justify-content:space-between;gap:5px;padding:14px 12px;font-size:8px;font-weight:700;letter-spacing:.5px}.mini-caption>span{color:#9a98a0;font-size:7px}.wellness-card{background:#c4b2f0;color:#24202c;width:270px;height:346px;right:27px;top:91px;transform:rotate(9deg);padding:22px;display:flex;flex-direction:column}.mini-top{font-size:9px;font-weight:800;letter-spacing:1.8px;display:flex;justify-content:space-between;z-index:1}.mini-top>span{font-size:20px}.wellness-card>p{position:relative;font-size:34px;line-height:1.05;letter-spacing:-1.5px;margin:auto 0;font-weight:700}.wellness-card em{font-style:normal;color:#645083}.mini-bottom{font-size:7px;letter-spacing:1.3px;line-height:1.7}.mini-bottom span{font-size:8px;letter-spacing:0;color:#514364}.wellness-rings{position:absolute;width:280px;height:280px;border:1px solid #61497a40;right:-160px;top:50px;border-radius:50%;box-shadow:0 0 0 20px #c4b2f0,0 0 0 21px #61497a30,0 0 0 40px #c4b2f0,0 0 0 41px #61497a25}.floating-note{position:absolute;right:12px;bottom:67px;padding:18px 24px;background:#202024ed;backdrop-filter:blur(14px);border:1px solid #ffffff18;border-radius:9px;width:263px;box-shadow:0 20px 60px #0005}.floating-note>span:first-child{font-size:8px;letter-spacing:1.1px;color:#b9b2c7}.floating-note strong{display:block;font-size:23px;letter-spacing:-.5px;line-height:1.1;margin-top:9px;font-weight:500}.floating-note>span:last-child{position:absolute;right:21px;bottom:21px;font-size:31px;color:var(--purple)}.art-footnote{position:absolute;bottom:8px;left:16px;right:0;display:flex;justify-content:space-between;gap:12px;font-size:9px;color:#96909f}.art-footnote span{font-size:8px;letter-spacing:1px}.impact-strip{border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:31px 0;display:grid;grid-template-columns:1fr 1.08fr 1.08fr 1.2fr;gap:20px;margin-top:25px}.impact-label .eyebrow{color:#a19aa9;font-size:8px}.impact-label p{font-size:15px;line-height:1.4;margin-top:9px}.metric{border-left:1px solid var(--line);padding-left:29px}.metric strong{font-size:43px;letter-spacing:-1.7px;font-weight:500}.metric strong span{color:var(--purple);font-size:31px}.metric p{font-size:12px;margin-top:6px}.metric small{font-size:9px;color:#9a95a1;display:block;margin-top:7px}.impact-note{padding:4px 0 0 20px;max-width:280px}.impact-note>span{font-size:10px;color:var(--purple)}.impact-note p{font-size:10px;line-height:1.65;color:#9a95a1;margin-top:8px}.work-section{padding-top:92px}.section-heading{display:flex;align-items:end;justify-content:space-between;gap:40px;margin-bottom:38px}.section-heading .eyebrow{color:var(--purple);font-size:9px;margin-bottom:20px}h2{font-size:clamp(30px,3.4vw,44px);line-height:1.12;letter-spacing:-1.7px;font-weight:500}h2>span{color:#929097}.section-heading>p{font-size:13px;line-height:1.65;color:#aaa6b0;padding-bottom:4px}.work-controls{border-top:1px solid var(--line);padding-top:22px;display:flex;justify-content:space-between;align-items:center;gap:24px}.filter-buttons{display:flex;gap:7px;flex-wrap:wrap}.filter{border:1px solid #38353f;border-radius:999px;padding:10px 16px;font-size:11px;color:#b9b4c2;white-space:nowrap}.filter:hover{border-color:var(--purple);color:var(--text)}.filter.active{background:var(--text);color:#222025;border-color:var(--text)}.filter span{font-size:8px;padding-left:4px;opacity:.7}.client-filter select{border:0;background:#1a191d;border-radius:6px;font-size:11px;padding:10px 28px 10px 12px;max-width:230px;cursor:pointer}.work-meta{display:flex;justify-content:space-between;gap:16px;margin:23px 0 16px;font-size:9px;color:#8f8a97}.work-meta>span:last-child{font-size:8px;letter-spacing:1px}.project-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:34px 22px}.project-card{min-width:0}.project-open{padding:0;width:100%;text-align:left;border:0;color:var(--text)}.project-visual{height:275px;overflow:hidden;border-radius:7px;position:relative;display:flex;flex-direction:column;justify-content:space-between;padding:23px;isolation:isolate;transition:transform .35s}.project-open:hover .project-visual{transform:translateY(-5px)}.project-open:hover .open-arrow{background:var(--purple);color:#1a1426;transform:rotate(45deg)}.project-visual>.visual-brand{font-size:9px;font-weight:700;letter-spacing:1.3px;max-width:70%;position:relative;z-index:1}.project-visual>.visual-headline{font-size:39px;line-height:1.02;letter-spacing:-1.8px;font-weight:600;max-width:240px;position:relative;z-index:1}.visual-caption{font-size:8px;letter-spacing:1px;position:relative;z-index:1}.visual-decoration{position:absolute;z-index:0;pointer-events:none}.theme-iron{background:#07367a;padding:0}.theme-iron img{width:100%;height:100%;object-fit:cover;object-position:50% 19%}.theme-clique{background:#c5b2ef;color:#2b2237}.theme-clique .visual-headline{font-size:47px;max-width:215px;z-index:2}.theme-clique .visual-decoration{width:180px;height:180px;border:1px solid #6d4c854d;border-radius:50%;right:-65px;bottom:10px;box-shadow:0 0 0 15px #c5b2ef,0 0 0 16px #6d4c8540,0 0 0 31px #c5b2ef,0 0 0 32px #6d4c8535}.theme-ascend{background:#dadcce;color:#2c3826}.theme-ascend .visual-decoration{width:190px;height:190px;right:-45px;bottom:-47px;transform:rotate(-45deg);background:repeating-linear-gradient(0deg,transparent 0 17px,#6d795649 18px 19px)}.theme-ascend .visual-headline{max-width:190px;font-weight:500}.theme-noah{background:#eac9a7;color:#66422b}.theme-noah .visual-headline{font-family:Georgia,serif;font-weight:400;font-style:italic;font-size:43px;max-width:215px;line-height:1.03}.theme-noah .visual-decoration{width:153px;height:153px;border:1px solid #a3764550;right:-55px;top:83px;border-radius:50%;box-shadow:0 0 0 18px #eac9a7,0 0 0 19px #a3764540}.theme-refuge{background:#193834;color:#d9efcf}.theme-refuge .visual-headline{max-width:210px}.theme-refuge .visual-decoration{width:150px;height:150px;background:repeating-linear-gradient(90deg,transparent 0 24px,#d9efcf12 25px 26px),repeating-linear-gradient(0deg,transparent 0 24px,#d9efcf12 25px 26px);right:-3px;bottom:0;transform:rotate(25deg)}.theme-pov{background:#444553;color:#f6e8dc}.theme-pov .visual-headline{font-family:Georgia,serif;font-style:italic;font-weight:400;font-size:42px;max-width:220px}.theme-pov .visual-decoration{width:170px;height:220px;right:15px;top:26px;border:1px solid #dccdba45;transform:rotate(12deg)}.project-info{padding:18px 0 0;display:grid;grid-template-columns:1fr auto;gap:8px}.project-info h3{font-size:16px;font-weight:500;letter-spacing:-.3px}.project-info p{font-size:10px;color:#a7a0af;margin-top:7px}.open-arrow{display:grid;place-items:center;width:32px;height:32px;border:1px solid #4d4854;border-radius:50%;transition:all .2s;font-size:18px}.project-tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:14px}.project-tags span{font-size:8px;letter-spacing:.3px;color:#9d98a4;border-bottom:1px solid #3d3744;padding-bottom:4px}.project-tags span:not(:last-child){margin-right:5px}.work-disclaimer{font-size:10px;line-height:1.6;color:#96909d;margin-top:30px;max-width:680px}.empty-state{padding:45px;text-align:center;border:1px solid var(--line);border-radius:8px}.empty-state p{color:var(--muted);margin:14px 0 22px}.about-section{padding-top:100px}.about-grid{display:grid;grid-template-columns:.88fr 1.4fr;gap:70px;padding-top:10px}.profile-panel{padding:34px;background:#1a191e;border:1px solid #2e2b33;border-radius:9px;position:relative}.monogram{height:64px;width:64px;border-radius:50%;background:var(--purple);color:#211a30;display:flex;align-items:center;justify-content:center;font-size:58px;font-weight:700;letter-spacing:-5px;position:relative;margin-bottom:35px;padding-right:4px}.monogram span{position:absolute;font-size:20px;right:-4px;top:0;color:var(--text);letter-spacing:0}.profile-panel>.eyebrow{color:#aaa0b8;font-size:8px}.profile-panel h3{font-size:34px;line-height:1.1;letter-spacing:-1px;font-weight:500;margin:13px 0 18px}.profile-panel>p:not(.eyebrow){font-size:12px;line-height:1.85;color:#b5aebc;max-width:350px}.experience{margin-top:29px;padding-top:22px;border-top:1px solid #38323f}.experience>span,.education>span{font-size:8px;letter-spacing:1.3px;color:#aaa0b8}.experience strong{font-size:12px;display:block;font-weight:500;margin-top:10px}.experience p,.education p{font-size:11px;line-height:1.7;color:#b5aebc;margin-top:5px}.education{margin-top:23px}.capability-row{display:grid;grid-template-columns:33px 1fr;gap:20px;padding:27px 0 30px;border-bottom:1px solid var(--line)}.capability-row:first-child{padding-top:3px}.row-number{color:var(--purple);font-size:10px;padding-top:6px}.capability-row h3{font-size:22px;font-weight:500;letter-spacing:-.6px}.capability-row p{color:#aaa4b2;font-size:12px;line-height:1.85;margin-top:12px;max-width:500px}.skill-tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:17px}.skill-tags span{font-size:9px;background:#211e28;padding:6px 9px;border-radius:4px;color:#c4b8d5}.tools-block{padding:27px 0 0 53px}.tools-block>.eyebrow{font-size:8px;color:#b0a5be}.tool-list{display:flex;flex-wrap:wrap;gap:12px 18px;margin-top:15px}.tool-list>span{font-size:12px;font-weight:500}.tools-block>p:last-child{font-size:10px;color:#938a9e;margin-top:17px;line-height:1.7}.contact-panel{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:49px 0 52px;border-top:1px solid var(--line);margin-top:67px}.contact-panel .eyebrow{font-size:8px;color:var(--purple);margin-bottom:18px}.contact-panel h2{font-size:42px}.contact-panel h2>span{color:var(--purple)}.contact-panel .button{min-width:169px}.footer{border-top:1px solid var(--line);display:flex;gap:20px;justify-content:space-between;align-items:center;padding-block:26px 30px}.footer .wordmark{font-size:24px}.footer p{font-size:10px;color:#99919f}.footer>div{display:flex;gap:22px;font-size:10px;color:#bcb3c4}.skip-link{position:fixed;left:20px;top:-100px;z-index:100;background:var(--purple);color:#111;padding:15px}.skip-link:focus{top:10px}.sr-only{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.draft-banner{padding:12px 24px;background:#c8b6ff;color:#201b2b;text-align:center;font-size:12px}.draft-banner a{margin-left:20px;text-decoration:underline}dialog{width:min(880px,calc(100% - 36px));max-height:90vh;padding:0;background:#1b191f;border:1px solid #4c4358;border-radius:15px;color:var(--text);overflow:auto}dialog::backdrop{background:#000b;backdrop-filter:blur(8px)}.dialog-close{position:absolute;z-index:4;right:18px;top:18px;border:1px solid #685d77;border-radius:50%;background:#1d1825;color:var(--text);width:35px;height:35px;line-height:1;font-size:26px}.dialog-header{padding:43px 55px 27px;border-bottom:1px solid var(--line)}.dialog-header .eyebrow{color:var(--purple);font-size:9px;margin-right:30px}.dialog-header h2{margin:13px 0 15px;font-size:35px}.dialog-header>p:last-child{font-size:14px;line-height:1.6;color:var(--muted);max-width:650px}.dialog-body{padding:30px 55px 40px;display:grid;grid-template-columns:1fr 1fr;gap:30px}.detail-block h3{font-size:10px;letter-spacing:1.5px;font-weight:600;color:var(--purple);margin-bottom:13px;text-transform:uppercase}.detail-block p,.detail-block li{font-size:12px;color:#c6bdcf;line-height:1.8}.detail-block ul{padding-left:16px;margin:0}.detail-block li+li{margin-top:7px}.detail-block+.detail-block{margin-top:25px}.sample-box{background:#c5b2ef;color:#30223e;border-radius:7px;padding:25px;white-space:pre-line;font-size:23px;letter-spacing:-.5px;line-height:1.25}.sample-label{font-size:9px!important;line-height:1.5!important;margin-top:10px;color:#ada2bb!important}.sample-image{width:100%;height:auto;border-radius:6px;margin-top:25px}.project-links{display:flex;flex-wrap:wrap;gap:8px;margin-top:24px}.project-links a{font-size:10px;border:1px solid #62536d;border-radius:30px;padding:10px 14px}.project-links a:hover{background:#35283f}.dialog-note{font-size:10px;color:#aba0b7;margin-top:18px;line-height:1.6}.editor-main{max-width:950px;margin:48px auto 80px}.editor-main h1{font-size:44px;letter-spacing:-1.5px;margin:14px 0}.editor-main .editor-intro{max-width:730px;font-size:13px;line-height:1.8;color:#bbb1c6}.editor-toolbar{display:flex;gap:10px;flex-wrap:wrap;margin:26px 0 20px}.editor-notice{border-left:2px solid var(--purple);padding:12px 16px;background:#221b2e;font-size:12px;color:#d0c2e4;line-height:1.7}.editor-section{margin-top:32px;border:1px solid var(--line);border-radius:9px;padding:25px}.editor-section h2{font-size:25px;letter-spacing:-.5px;margin-bottom:20px}.editor-fields{display:grid;grid-template-columns:1fr 1fr;gap:18px}.field{display:flex;flex-direction:column;gap:8px;font-size:11px;color:#c5b7d6}.field.wide{grid-column:1/-1}.field input,.field textarea,.field select{width:100%;border:1px solid #4a4056;border-radius:5px;background:#121014;padding:12px;font-size:13px;color:var(--text)}.field textarea{min-height:94px;resize:vertical;line-height:1.6}.field small{font-size:10px;color:#a496b4;line-height:1.5}.editor-project{border:1px solid var(--line);border-radius:8px;margin-top:13px}.editor-project summary{padding:19px 22px;cursor:pointer;font-size:14px}.editor-project[open] summary{border-bottom:1px solid var(--line);color:var(--purple)}.editor-project .editor-fields{padding:22px}.editor-remove{font-size:11px;color:#efbcbc;border:1px solid #795252;border-radius:5px;padding:10px 13px;justify-self:start}.editor-status{min-height:22px;font-size:12px;color:#d1c1ec;margin:12px 0}.editor-add{margin-top:20px}.editor-footer-note{font-size:12px;color:#a99ab9;line-height:1.8;margin-top:22px}
@media(min-width:1450px){.hero-art{margin-left:35px}.hero-grid{gap:60px}.equipment-card{width:255px}.equipment-card>img{height:301px}.wellness-card{width:287px;height:368px}.wellness-card>p{font-size:38px}}
@media(max-width:1100px){.container{width:calc(100% - 60px)}.hero-grid{gap:14px}.hero-art{transform:scale(.88);transform-origin:right center;margin-left:-40px}.hero-location{font-size:9px}.metric{padding-left:20px}.impact-note{padding-left:10px}.project-visual{height:245px}.project-visual>.visual-headline{font-size:34px}.theme-clique .visual-headline{font-size:42px}.about-grid{gap:40px}.section-heading>p{font-size:12px}}
@media(max-width:800px){.container{width:calc(100% - 40px)}.nav-wrap{height:72px}nav{gap:18px;font-size:11px}.nav-contact{padding:10px 13px}.hero{padding-top:43px}.hero-grid{grid-template-columns:1.05fr 1fr;gap:0}h1{font-size:58px;letter-spacing:-3.3px}.hero-art{transform:scale(.72);width:430px;margin-left:-90px;height:575px}.hero-intro{font-size:15px}.hero-description{font-size:12px}.desktop-break{display:none}.hero-location{max-width:285px;line-height:1.5}.impact-strip{grid-template-columns:1fr 1fr 1fr;gap:15px}.impact-note{grid-column:1/-1;max-width:none;padding:13px 0 0;display:flex;gap:15px;border-top:1px solid var(--line);align-items:center}.impact-note p{margin:0;font-size:9px;max-width:550px}.impact-note>span{min-width:145px;font-size:9px}.impact-label p{font-size:13px}.metric strong{font-size:35px}.metric small{font-size:8px}.section-heading>p{font-size:11px}.work-section{padding-top:68px}.project-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:28px 19px}.project-visual{height:260px}.about-section{padding-top:75px}.about-grid{gap:27px;grid-template-columns:.9fr 1.2fr}.profile-panel{padding:25px}.capability-row{gap:12px;grid-template-columns:22px 1fr}.capability-row h3{font-size:19px}.tools-block{padding-left:34px}.contact-panel h2{font-size:34px}.contact-panel .eyebrow{letter-spacing:1.4px}.footer{flex-wrap:wrap}.footer>p{display:none}.work-controls{align-items:start;gap:15px}.filter{padding:9px 12px;font-size:10px}.client-filter select{max-width:170px}.dialog-body{padding:25px 30px 35px;gap:24px}.dialog-header{padding:35px 30px 25px}.editor-main{margin-top:35px}}
@media(max-width:600px){html{scroll-padding-top:88px}.container{width:calc(100% - 36px)}.nav-wrap{height:68px}.wordmark{font-size:26px}nav{gap:18px;font-size:10px}nav>a:nth-child(2){display:none}.nav-contact{padding:9px 12px}.nav-contact span{margin-left:8px}.hero{padding-top:34px}.hero-grid{grid-template-columns:1fr}.hero-copy{padding-bottom:0}.hero-copy>.eyebrow{font-size:8px;letter-spacing:1.55px}h1{font-size:clamp(54px,14vw,72px);letter-spacing:-3.4px;margin:23px 0;line-height:1.02}.hero-intro{font-size:16px;max-width:340px}.hero-description{font-size:13px;max-width:320px}.hero-copy>.button{margin-top:24px}.hero-location{font-size:9px;margin-top:18px;max-width:none}.hero-art{width:100%;height:440px;min-height:440px;margin:19px 0 0;transform:none}.equipment-card{width:46%;top:114px;left:2%}.equipment-card>img{height:207px}.mini-caption{padding:11px 9px;font-size:6px}.mini-caption>span{font-size:5px}.wellness-card{width:53%;right:3%;height:267px;top:45px;padding:16px}.wellness-card>p{font-size:clamp(25px,7vw,31px);letter-spacing:-1.1px}.mini-top{font-size:7px;letter-spacing:1.1px}.mini-bottom{font-size:5px;letter-spacing:1px}.mini-bottom>span{font-size:6px}.floating-note{width:195px;right:0;bottom:35px;padding:14px 18px}.floating-note>span:first-child{font-size:6px}.floating-note strong{font-size:19px}.floating-note>span:last-child{font-size:25px;right:15px;bottom:15px}.art-star{font-size:66px;top:-1px;right:0}.art-label{font-size:6px;letter-spacing:1px;top:0;left:3px}.art-footnote{font-size:7px;left:0;bottom:0}.art-footnote span{font-size:6px}.orbit-one{width:280px;height:280px;top:85px;left:7%}.orbit-two{width:250px;height:330px;left:17%;top:43px}.impact-strip{margin-top:29px;padding:25px 0;grid-template-columns:1fr 1fr;gap:22px 17px}.impact-label{grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;gap:20px}.impact-label p{margin:0;font-size:12px;line-height:1.45}.impact-label p br{display:none}.metric{padding-left:0;border:0}.metric:nth-child(3){border-left:1px solid var(--line);padding-left:18px}.metric strong{font-size:38px}.metric p{font-size:11px}.metric small{font-size:8px;line-height:1.5}.impact-note{display:block;padding-top:15px}.impact-note p{margin-top:7px;font-size:9px}.work-section{padding-top:53px}.section-heading{display:block;margin-bottom:25px}.section-heading .eyebrow{font-size:8px;margin-bottom:15px}h2{font-size:32px;letter-spacing:-1.4px}.section-heading>p{font-size:12px;margin-top:18px}.section-heading>p br{display:none}.work-controls{display:block}.filter-buttons{gap:6px}.filter{font-size:10px;padding:9px 12px}.client-filter{display:block;margin-top:13px}.client-filter select{width:100%;max-width:none;border:1px solid #37303e;font-size:11px}.work-meta{margin:17px 0 14px}.work-meta>span:last-child{font-size:6px;letter-spacing:.5px}.project-grid{grid-template-columns:1fr;gap:29px}.project-visual{height:300px;padding:25px}.theme-iron{padding:0}.theme-iron img{object-position:50% 24%}.project-visual>.visual-headline{font-size:44px;max-width:265px}.theme-clique .visual-headline{font-size:52px}.theme-ascend .visual-headline{max-width:215px}.project-info h3{font-size:17px}.project-info p{font-size:10px}.project-tags{margin-top:12px}.work-disclaimer{font-size:9px;margin-top:26px}.about-section{padding-top:58px}.about-grid{grid-template-columns:1fr;gap:33px;padding-top:0}.profile-panel{padding:27px}.profile-panel h3{font-size:32px}.profile-panel h3 br{display:none}.monogram{margin-bottom:26px}.profile-panel>p:not(.eyebrow){max-width:none}.education p br:nth-child(2){display:none}.capability-row{grid-template-columns:23px 1fr;padding:24px 0;gap:15px}.capability-row h3{font-size:21px}.capability-row p{font-size:12px}.tools-block{padding-left:38px}.tool-list{gap:13px 18px}.contact-panel{align-items:start;flex-direction:column;margin-top:42px;padding:33px 0 36px;gap:24px}.contact-panel h2{font-size:33px}.contact-panel .eyebrow{font-size:7px;letter-spacing:1.1px}.footer{padding-block:21px 25px;gap:18px}.footer>div{gap:17px;font-size:9px}.dialog-header{padding:35px 24px 22px}.dialog-header h2{font-size:28px;letter-spacing:-.8px}.dialog-header>p:last-child{font-size:12px}.dialog-body{grid-template-columns:1fr;padding:24px;gap:29px}.dialog-close{right:12px;top:12px;width:31px;height:31px}.dialog-header .eyebrow{font-size:8px}.sample-box{font-size:24px}.draft-banner{font-size:10px;padding:10px}.draft-banner a{display:inline-block;margin-top:6px;margin-left:8px}.editor-main h1{font-size:35px;letter-spacing:-1px}.editor-toolbar .button{padding:12px 17px;font-size:11px}.editor-fields{grid-template-columns:1fr}.field.wide{grid-column:auto}.editor-section{padding:19px}.editor-project .editor-fields{padding:19px}.editor-notice{font-size:11px}.editor-project summary{font-size:13px}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}*,*::before,*::after{transition:none!important;animation:none!important}}
```

## public/enhancements.css

```css
/* Creative portfolio upgrade: dimensional surfaces, controlled motion, rich client detail. */
:root{--mint:#d4f5ae;--purple:#bcabff}
.portfolio-page{background:radial-gradient(ellipse at 85% 8%,#28213b50,transparent 27%),#101014}
#scroll-progress{position:fixed;z-index:50;top:0;left:0;width:100%;height:2px;background:linear-gradient(90deg,var(--purple),var(--mint));transform:scaleX(0);transform-origin:left}
.site-header{background:#101014e8}.nav-contact:hover{border-color:var(--purple);background:#bcabff12}
.hero{padding-top:48px}.hero-grid{grid-template-columns:1fr 1.08fr;gap:24px;min-width:0}.hero-copy,.hero-art{min-width:0}
h1{font-size:clamp(60px,5.5vw,80px);letter-spacing:-4.5px}h1>span{background:linear-gradient(110deg,#d7ccff 3%,#b59af8 50%,#9a85de);-webkit-background-clip:text;background-clip:text;color:transparent}
.primary{box-shadow:0 5px 27px #9970f221}.primary:hover{box-shadow:0 8px 35px #9970f23a}
.studio-scene{height:626px;min-height:626px;width:100%;margin:0;transform:none;isolation:isolate;perspective:1100px;border:1px solid #b7a0fb15;border-radius:22px;background:radial-gradient(ellipse at 54% 42%,#4e377724,transparent 60%),linear-gradient(160deg,#22202c55,#14131966);overflow:clip;overflow-clip-margin:0}
.scene-title{position:absolute;z-index:4;top:23px;left:22px;right:22px;display:flex;align-items:center;gap:9px;font-size:8px;color:#b6a8ca;letter-spacing:1.2px}.scene-title>span:last-child{margin-left:auto;font-size:10px;color:#72647f}
.scene-grid{position:absolute;inset:10% -30% -15%;background:linear-gradient(#a197b70a 1px,transparent 1px),linear-gradient(90deg,#a197b70a 1px,transparent 1px);background-size:42px 42px;transform:perspective(700px) rotateX(55deg) rotateZ(-18deg);mask-image:radial-gradient(ellipse,#000 10%,transparent 65%);pointer-events:none}
.scene-glow{position:absolute;width:330px;height:330px;left:22%;top:21%;border-radius:50%;background:#ae87ff15;filter:blur(40px);pointer-events:none}
#scene-host{position:absolute;inset:32px -12px 35px;pointer-events:none;z-index:0}#scene-host canvas{width:100%;height:100%;display:block;position:absolute;inset:0}
.scene-fallback{position:absolute;width:58%;aspect-ratio:1;left:22%;top:13%;border:48px solid #b3a2f7;border-radius:46%;transform:rotate(-27deg) rotateY(38deg);box-shadow:inset 7px 8px 15px #fff9,inset -15px -15px 17px #473479,17px 13px 34px #0008;opacity:.7}
[data-render="webgl"] .scene-fallback{display:none}
.studio-scene .equipment-card{width:190px;left:25px;top:235px;background:#131117;border:5px solid #30303a;border-radius:23px;box-shadow:2px 3px 0 #655c74,8px 10px 0 #24202c,16px 28px 35px #0008;transform:rotate(-12deg) rotateY(12deg);padding-top:18px;z-index:2;animation:phone-drift 9s ease-in-out infinite}
.phone-camera{position:absolute;width:38%;height:8px;background:#050507;border-radius:9px;left:31%;top:6px}
.studio-scene .equipment-card>img{height:219px;object-position:center;object-fit:cover;border-radius:7px}
.studio-scene .mini-caption{font-size:6px;padding:10px 5px}.studio-scene .mini-caption>span{font-size:5px}
.studio-scene .wellness-card{width:185px;height:207px;top:120px;right:21px;padding:18px;border:1px solid #e7deffb3;border-radius:10px;background:linear-gradient(135deg,#e5dcff,#b2a0dc);transform:rotate(10deg) rotateY(-13deg);box-shadow:-2px 3px 0 #7d6f9a,-6px 7px 0 #43394f,0 25px 42px #0007;z-index:2;animation:card-drift 11s ease-in-out infinite}
.studio-scene .wellness-card>p{font-size:26px;line-height:1.05;letter-spacing:-1.2px;margin:auto 0}.studio-scene .wellness-card em{color:#615079}.studio-scene .mini-top{font-size:7px;letter-spacing:1px}.studio-scene .mini-top>span{font-size:16px}.studio-scene .mini-bottom{font-size:5px;letter-spacing:.8px}.studio-scene .mini-bottom>span{font-size:7px}
.studio-scene .floating-note{bottom:68px;right:21px;width:235px;background:#27232ddb;border:1px solid #c9b7ed37;box-shadow:0 22px 40px #0004,inset 0 1px 0 #e2d8f51c;transform:rotate(-4deg);padding:19px 22px;z-index:3;border-radius:12px}.studio-scene .floating-note strong{font-size:27px;letter-spacing:-1px}.studio-scene .floating-note strong>span{color:var(--mint)}.studio-scene .floating-note>span:last-child{color:var(--mint);font-size:38px;bottom:19px;right:16px}.studio-scene .floating-note>span:first-child{font-size:6px;letter-spacing:1.2px}
.scene-pill{position:absolute;bottom:226px;right:26px;z-index:3;padding:10px 13px;border:1px solid #d6f7b752;border-radius:999px;background:#202b23d9;backdrop-filter:blur(12px);font-size:7px;letter-spacing:.7px;color:#e2f7cd;transform:rotate(5deg)}.scene-pill>span{font-size:13px;margin-right:7px}
.studio-scene .art-footnote{bottom:20px;left:22px;right:22px;font-size:8px;color:#a197af;z-index:3}.studio-scene .art-footnote>span{font-size:6px;letter-spacing:.6px}
.motion-toggle{position:absolute;top:54px;right:19px;z-index:5;display:flex;gap:7px;align-items:center;border:1px solid #84779350;border-radius:30px;padding:6px 10px;background:#1b1721a6;font-size:8px;color:#c7b8db}.motion-toggle:hover{border-color:#b6a0ff}.motion-toggle>span{font-size:10px}
.client-ribbon{display:flex;align-items:center;gap:29px;margin-top:37px;padding:24px 0;border-top:1px solid #b9a4ff20;border-bottom:1px solid #b9a4ff20}.client-ribbon>p{font-size:7px;color:#94899f;letter-spacing:1.4px;min-width:140px;line-height:1.7}#client-ribbon{display:flex;justify-content:space-between;align-items:center;gap:22px;flex:1;flex-wrap:wrap}#client-ribbon button{border:0;color:#c2b9cc;font-size:13px;font-weight:600;letter-spacing:-.3px;padding:6px 0;transition:color .2s}#client-ribbon button:hover{color:var(--purple)}
.impact-strip{margin-top:0;border-top:0}.work-section{padding-top:80px}.work-controls{gap:15px}.filter-buttons{gap:6px}.filter{font-size:10px;padding:10px 14px}.filter.active{background:var(--purple);border-color:var(--purple);color:#21152e}.client-filter select{border:1px solid #4e425f;background:#1a1720;max-width:200px}
.discovery-row{display:flex;gap:13px;align-items:center;margin-top:17px}.project-search{display:flex;align-items:center;gap:10px;border:1px solid #37313f;border-radius:7px;padding:0 13px;flex:1;background:#17151c}.project-search>span{font-size:22px;color:#ad9fbf}.project-search input{background:transparent;border:0;width:100%;min-width:0;font-size:11px;color:#ddd4e7;padding:13px 0;outline-offset:2px}.project-search input::placeholder{color:#94879f}.industry-filter select{background:#17151c;border:1px solid #37313f;border-radius:7px;padding:12px;font-size:11px;max-width:185px}.edit-clients-link{font-size:10px;color:#bbaaD0;white-space:nowrap;padding:10px}.edit-clients-link:hover{color:#e3d6fa}.work-meta{margin-top:20px}
.project-grid{gap:22px;perspective:1800px}.project-card{border:1px solid #bbaaD020;border-radius:14px;padding:10px 10px 17px;background:linear-gradient(150deg,#221e2b90,#18151d);position:relative;transform:rotateX(var(--tilt-x,0deg)) rotateY(var(--tilt-y,0deg));transition:transform .22s ease,border-color .25s,box-shadow .25s;transform-style:preserve-3d;isolation:isolate}.project-card:hover{border-color:#bbaaD06b;box-shadow:0 18px 45px #0004}.project-card::after{content:"";position:absolute;inset:0;border-radius:inherit;background:radial-gradient(circle at var(--shine-x,50%) var(--shine-y,0%),#ebdaff10,transparent 52%);pointer-events:none;z-index:0}.project-open{position:relative;z-index:1}.project-visual{height:259px;border-radius:7px}.project-open:hover .project-visual{transform:none}.project-info{padding:18px 7px 0;align-items:center}.project-info h3{font-size:16px}.project-info p{font-size:9px;line-height:1.5}.project-tags{padding:0 7px}.project-description{font-size:11px;line-height:1.7;color:#aa9cb8;margin:13px 7px 0;min-height:38px}.card-links{display:flex;gap:14px;padding:14px 7px 0;font-size:9px;position:relative;z-index:2}.card-links>a{color:#cfbde5}.card-links>a:hover{text-decoration:underline}.card-links>span{color:#83758f}.project-card .open-arrow{border-color:#695779;background:#2d223a}
.project-visual .visual-decoration{border-width:2px;filter:drop-shadow(4px 9px 8px #0002)}.theme-clique .visual-decoration{border:27px solid #9477b245;box-shadow:inset 4px 4px 8px #ebdef966,9px 8px 13px #9374b733;right:-25px;bottom:24px;transform:rotateY(45deg) rotateZ(-20deg)}.theme-ascend .visual-decoration{background:linear-gradient(125deg,#a9b29455,#edf1de75);border:2px solid #edf1de88;border-radius:24px;box-shadow:8px 8px 0 #87946533;right:-42px;bottom:-56px;transform:perspective(500px) rotateY(-20deg) rotateZ(30deg)}.theme-pov{background:radial-gradient(ellipse at 95% 15%,#8f789858,transparent 70%),#393746}.theme-pov .visual-decoration{border:12px solid #9985943b;box-shadow:inset 4px 6px 10px #e1d3e021,6px 8px 10px #0003;border-radius:5px;right:-30px;transform:perspective(400px) rotateY(-32deg) rotateZ(16deg)}
.theme-eclipse{background:#f0a77e;color:#462714}.theme-eclipse .visual-headline{font-size:42px;max-width:220px}.theme-eclipse .visual-decoration{right:-26px;bottom:25px;width:155px;height:155px;border:28px solid #c5724d55;border-radius:50%;transform:rotateY(50deg);box-shadow:inset 5px 5px 6px #fff5,6px 8px 10px #ac664347}
.theme-health{background:#b5d7c2;color:#21493d}.theme-health .visual-headline{font-family:Georgia,serif;font-weight:400;font-size:39px;max-width:236px}.theme-health .visual-decoration{width:160px;height:160px;right:-30px;bottom:-30px;border-radius:50%;background:radial-gradient(circle at 30% 25%,#eaffed,#77a58d 65%,#375e46);box-shadow:10px 15px 28px #4b796852;opacity:.4}
.theme-scholar{background:#bfd0ed;color:#233453}.theme-scholar .visual-decoration{width:150px;height:185px;right:-15px;bottom:-10px;border:1px solid #e8efff;background:linear-gradient(120deg,#dce5ff5e,#6789b752);box-shadow:7px 5px 0 #86a2cb77,14px 10px 0 #86a2cb55;border-radius:11px;transform:perspective(400px) rotateY(-28deg) rotateZ(13deg)}
.theme-merge{background:#bbaed5;color:#302740}.theme-merge .visual-headline{font-size:40px}.theme-merge .visual-decoration{width:165px;height:165px;right:-60px;bottom:14px;border:24px solid #7e689d48;border-radius:30px;transform:rotateZ(35deg);box-shadow:inset 5px 5px 8px #e7dff866,6px 8px 12px #694b8744}
.theme-property{background:#d8d1b9;color:#494533}.theme-property .visual-headline{font-family:Georgia,serif;font-weight:400;font-size:40px}.theme-property .visual-decoration{width:140px;height:200px;border-radius:70px 70px 0 0;right:-20px;bottom:0;border:25px solid #9b967333;box-shadow:inset 4px 3px 6px #fffae855;transform:rotate(-10deg)}
.work-more{text-align:center;margin-top:29px}.work-more:has(button[hidden]){display:none}.work-disclaimer{max-width:740px}.profile-panel{background:radial-gradient(circle at 90% 10%,#6b4c8f1f,transparent 60%),#1b1821}.monogram{box-shadow:3px 5px 0 #675489,9px 10px 21px #0005;transform:rotate(-5deg)}.skill-tags span{border:1px solid #bcabff13}.contact-panel{background:radial-gradient(ellipse at 90% 65%,#b5a1ff0a,transparent 50%)}
.dialog-header{background:radial-gradient(ellipse at 90% 0%,#8a62bb25,transparent 70%)}.dialog-facts{padding:21px 55px;background:#241d2e;display:grid;grid-template-columns:1fr 1.4fr;gap:23px;border-bottom:1px solid #493853}.dialog-facts h3{font-size:8px;letter-spacing:1.3px;color:#bfa8d9;text-transform:uppercase;margin-bottom:8px}.dialog-facts p{font-size:11px;color:#d2c4e1;line-height:1.7}.dialog-deliverables{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}.dialog-deliverables>span{border:1px solid #635074;background:#2f243d;padding:5px 8px;font-size:9px;border-radius:4px;color:#cbbbdd}.dialog-body{gap:32px}.image-upload{border:1px dashed #6e5688;border-radius:7px;padding:14px;background:#211a2b}.image-upload input{border:0;background:none;padding:5px 0;font-size:11px}.upload-preview{max-width:110px;max-height:150px;object-fit:contain;border-radius:5px;margin-top:8px}.editor-layout-nav{display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;gap:20px}.editor-layout-nav>a{color:var(--purple);font-size:12px}.editor-note{font-size:11px;color:#9e90af;line-height:1.7}.editor-project summary::marker{color:var(--purple)}
@keyframes phone-drift{0%,100%{transform:translateY(0) rotate(-12deg) rotateY(12deg)}50%{transform:translateY(-8px) rotate(-10deg) rotateY(12deg)}}
@keyframes card-drift{0%,100%{transform:translateY(0) rotate(10deg) rotateY(-13deg)}50%{transform:translateY(7px) rotate(8deg) rotateY(-13deg)}}
.motion-off .mini-card{animation:none!important}.motion-off .project-card{transform:none!important;transition:none!important}
@media(min-width:1450px){.hero-grid{gap:46px}.studio-scene{margin:0}.studio-scene .equipment-card{left:28px}.studio-scene .wellness-card{right:26px}}
@media(max-width:1100px){.hero-grid{gap:17px}.studio-scene{transform:none;margin:0;height:600px;min-height:600px}.studio-scene .equipment-card{width:159px;top:256px;left:18px;border-radius:19px}.studio-scene .equipment-card>img{height:188px}.studio-scene .wellness-card{width:159px;height:185px;right:13px;top:113px;padding:15px}.studio-scene .wellness-card>p{font-size:24px}.studio-scene .floating-note{width:198px;bottom:59px;right:15px;padding:18px}.studio-scene .floating-note strong{font-size:25px}.studio-scene .floating-note>span:last-child{font-size:31px}.studio-scene .floating-note>span:first-child{font-size:5px}.scene-pill{right:15px;bottom:206px;font-size:6px;padding:8px 10px}.studio-scene .pointer-hint{display:none}.project-visual{height:240px}.project-visual>.visual-headline{font-size:36px}.theme-clique .visual-headline{font-size:44px}.client-ribbon{gap:20px}#client-ribbon{gap:10px 18px}#client-ribbon button{font-size:11px}.filter{font-size:9px;padding:9px 11px}.edit-clients-link{font-size:9px}.project-info h3{font-size:14px}}
@media(max-width:800px){.hero-grid{grid-template-columns:1fr .92fr;gap:18px}h1{font-size:57px;letter-spacing:-3.5px}.studio-scene{width:100%;height:560px;min-height:560px}.studio-scene .equipment-card{width:142px;left:18px;top:245px}.studio-scene .equipment-card>img{height:171px}.studio-scene .wellness-card{width:136px;height:173px;right:13px;top:104px;padding:13px}.studio-scene .wellness-card>p{font-size:21px}.studio-scene .mini-top{font-size:6px}.studio-scene .mini-bottom{font-size:4px;letter-spacing:.4px}.studio-scene .mini-bottom>span{font-size:6px}.studio-scene .floating-note{width:162px;bottom:52px;right:14px;padding:13px}.studio-scene .floating-note strong{font-size:21px}.studio-scene .floating-note>span:first-child{font-size:4px}.studio-scene .floating-note>span:last-child{font-size:23px;right:10px}.scene-pill{bottom:169px;right:12px;font-size:5px;letter-spacing:.3px}.scene-title{font-size:6px;left:15px;right:15px}.scene-title>span:last-child{font-size:8px}.client-ribbon{align-items:start}.client-ribbon>p{min-width:104px;max-width:104px}.client-filter select{max-width:175px}.work-controls{flex-wrap:wrap}.discovery-row{flex-wrap:wrap}.project-search{min-width:260px}.industry-filter select{max-width:170px}.edit-clients-link{padding:0;margin-top:2px;margin-left:auto}.project-visual{height:267px}.project-info h3{font-size:16px}.dialog-facts{padding:20px 30px}}
@media(max-width:600px){.hero{padding-top:32px}.hero-grid{grid-template-columns:1fr;gap:0}h1{font-size:clamp(54px,14vw,72px);letter-spacing:-3.4px}.studio-scene{width:100%;height:478px;min-height:478px;margin-top:30px;border-radius:16px}.scene-title{font-size:6px;left:16px;right:16px;top:19px}.scene-title>span:last-child{font-size:8px}.scene-glow{width:260px;height:260px;left:10%;top:20%}#scene-host{inset:12px -28px 6px}.studio-scene .equipment-card{width:145px;left:18px;top:185px;padding-top:16px;border-width:4px;border-radius:18px}.studio-scene .equipment-card>img{height:173px}.studio-scene .mini-caption{font-size:5px;padding:8px 5px}.studio-scene .mini-caption>span{font-size:4px}.studio-scene .wellness-card{width:142px;height:164px;right:16px;top:78px;padding:13px}.studio-scene .wellness-card>p{font-size:21px}.studio-scene .mini-top{font-size:6px}.studio-scene .floating-note{width:173px;right:15px;bottom:50px;padding:14px}.studio-scene .floating-note strong{font-size:22px}.studio-scene .floating-note>span:first-child{font-size:4px}.studio-scene .floating-note>span:last-child{font-size:29px;right:13px;bottom:12px}.scene-pill{right:12px;bottom:169px;font-size:5px;letter-spacing:.4px;padding:8px 9px}.scene-pill>span{font-size:10px;margin-right:3px}.motion-toggle{top:43px;right:13px;font-size:7px;padding:5px 8px}.studio-scene .art-footnote{left:16px;bottom:17px;font-size:7px}.studio-scene .art-footnote>span{font-size:5px}.client-ribbon{margin-top:28px;padding:20px 0;display:block}.client-ribbon>p{max-width:none;margin-bottom:13px;font-size:7px;letter-spacing:1.2px}#client-ribbon{display:flex;gap:8px 19px;justify-content:flex-start}#client-ribbon button{font-size:12px;padding:4px 0}.impact-strip{margin-top:0}.work-section{padding-top:52px}.filter-buttons{gap:6px}.filter{padding:9px 12px;font-size:10px}.client-filter{width:100%;margin-top:14px}.client-filter select{width:100%;max-width:none}.discovery-row{gap:10px;margin-top:12px}.project-search{min-width:0;flex-basis:100%;padding:0 12px}.project-search input{font-size:11px}.industry-filter{flex:1}.industry-filter select{width:100%;max-width:none;font-size:10px}.edit-clients-link{font-size:9px;margin:0;padding:8px 0}.work-meta{margin-top:18px}.project-grid{gap:20px}.project-card{padding:9px 9px 17px;border-radius:13px}.project-visual{height:287px;padding:23px}.theme-iron{padding:0}.project-visual>.visual-headline{font-size:43px;max-width:250px}.theme-clique .visual-headline{font-size:48px}.theme-ascend .visual-headline{max-width:190px}.project-info{padding:17px 7px 0}.project-info h3{font-size:16px}.project-description{min-height:0;font-size:11px}.card-links{font-size:10px}.work-more{margin-top:25px}.dialog-facts{grid-template-columns:1fr;gap:17px;padding:20px 24px}.dialog-body{gap:24px}.editor-layout-nav{align-items:start}.editor-layout-nav>a{white-space:nowrap;font-size:10px}.editor-note{font-size:10px}.scene-fallback{border-width:35px;top:17%;left:22%}}
@media(prefers-reduced-motion:reduce){.mini-card{animation:none!important}.project-card{transform:none!important}}
```

## public/refinements.css

```css
/* Focused portfolio, personal hero, and visible contact details. */
.hero h1{font-size:clamp(55px,4.8vw,69px);letter-spacing:-3.6px;line-height:1.06}.hero-description{max-width:400px}.client-ribbon{margin-top:35px}.work-section{padding-top:66px}
.studio-scene .personal-card{background:#131218;padding-top:18px}.creative-cover{height:219px;background:radial-gradient(circle at 95% 12%,#daf9c6 0,transparent 45%),linear-gradient(140deg,#e9dfff,#c2addf);color:#34253e;position:relative;overflow:hidden;border-radius:7px;padding:15px 12px;display:flex;flex-direction:column;justify-content:space-between}.cover-signature{display:flex;justify-content:space-between;font-size:7px;letter-spacing:2px;font-weight:700;z-index:1}.cover-signature>span{font-size:16px;line-height:1;letter-spacing:0}.cover-copy{position:relative;z-index:1;margin-top:auto;margin-bottom:15px}.cover-copy>small{display:block;font-size:5px;font-weight:600;letter-spacing:.75px;margin-bottom:6px}.cover-copy>strong{display:block;font-size:30px;line-height:.98;letter-spacing:-1.2px;font-weight:700}.cover-copy>p{font-size:7px;line-height:1.5;max-width:125px;margin-top:9px;color:#655075}.cover-bottom{display:flex;justify-content:space-between;align-items:center;font-size:4px;letter-spacing:.8px;font-weight:700;position:relative;z-index:1}.cover-bottom>span{font-size:12px}.cover-sculpture{position:absolute;right:-18px;top:23px;width:85px;height:85px;transform:rotate(-22deg);opacity:.78}.cover-sculpture i{position:absolute;inset:0;border:10px solid #a083c457;border-radius:50%;box-shadow:inset 3px 3px 5px #fff9,4px 5px 7px #70548040;transform:rotateY(43deg)}.cover-sculpture i:nth-child(2){transform:rotateX(55deg) rotateZ(20deg)}.cover-sculpture i:nth-child(3){transform:rotateY(-42deg) rotateZ(-20deg)}
.sample-pending{border:1px solid #bca3d747;border-radius:10px;min-height:175px;background:radial-gradient(ellipse at 20% 10%,#c1a3e022,transparent 75%);padding:28px;display:flex;flex-direction:column;justify-content:center;gap:17px}.sample-pending>span{font-size:35px;color:var(--purple)}.sample-pending h3{font-size:20px;font-weight:500;letter-spacing:-.4px;line-height:1.3}
nav .nav-contact{font-size:inherit;line-height:inherit;color:inherit}.nav-contact:hover{color:var(--purple)}#contact-dialog{width:min(600px,calc(100% - 36px));background:radial-gradient(ellipse at 100% 0%,#674c8140,transparent 75%),#1b1722}.contact-dialog-content{padding:46px 39px 28px}.contact-dialog-content>.eyebrow{font-size:8px;color:var(--purple);margin-bottom:17px;padding-right:18px}.contact-dialog-content h2{font-size:48px;margin-bottom:18px}.contact-dialog-content h2>span{color:var(--purple)}#contact-description{font-size:13px;color:#bcb0c8;line-height:1.6;margin-bottom:20px}.contact-email{font-size:clamp(16px,2.4vw,24px);letter-spacing:-.4px;font-weight:500;color:#dcd0ff;display:block;overflow-wrap:anywhere;line-height:1.5;padding:14px 0;border-top:1px solid #6d58823b;border-bottom:1px solid #6d58823b;user-select:all}.contact-email:hover{color:#fff}.contact-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:23px}.contact-actions .button{font-size:11px;padding:13px 18px;gap:16px}#copy-status{min-height:22px;margin-top:17px;font-size:11px;line-height:1.6;color:#c5e4a9}
@media(max-width:1100px){.hero h1{font-size:clamp(48px,5.1vw,61px);letter-spacing:-3px}.studio-scene .creative-cover{height:188px;padding:12px 10px}.cover-copy>strong{font-size:26px}.cover-copy>small{font-size:4px}.cover-copy>p{font-size:6px}.cover-sculpture{width:74px;height:74px;top:26px;right:-19px}.cover-bottom{font-size:3px}}
@media(max-width:800px){.hero h1{font-size:44px;letter-spacing:-2.5px}.studio-scene .creative-cover{height:171px;padding:10px 9px}.cover-copy>strong{font-size:24px}.cover-signature{font-size:6px}.cover-copy{margin-bottom:10px}.cover-copy>p{font-size:5px}.cover-sculpture{width:69px;height:69px;top:24px;right:-17px}.cover-sculpture i{border-width:8px}}
@media(max-width:600px){.hero h1{font-size:clamp(44px,12vw,65px);letter-spacing:-2.8px;margin:24px 0;line-height:1.06}.hero-description{max-width:350px}.studio-scene .creative-cover{height:173px;padding:11px 9px}.cover-copy>strong{font-size:24px}.cover-copy>small{font-size:4px}.cover-copy>p{font-size:6px}.cover-signature{font-size:6px}.cover-bottom{font-size:3px}.cover-sculpture{width:72px;height:72px;right:-19px;top:26px}.client-ribbon{margin-top:27px}.work-section{padding-top:50px}.contact-dialog-content{padding:38px 23px 24px}.contact-dialog-content>.eyebrow{font-size:7px;letter-spacing:1.3px}.contact-dialog-content h2{font-size:40px}#contact-description{font-size:12px}.contact-email{font-size:17px;letter-spacing:-.5px}.contact-actions{gap:8px}.contact-actions .button{font-size:10px;padding:12px 13px;gap:10px}}

/* Public client imagery and direct Instagram links. */
.project-visual.client-preview{padding:0;isolation:isolate;background:#222026;display:block;position:relative;overflow:hidden}
.client-preview>img{width:100%;height:100%;object-fit:cover;object-position:center;display:block}
.client-preview.focus-top>img{object-position:50% 25%}.client-preview.focus-bottom>img{object-position:50% 75%}
.client-preview::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,#0002,transparent 38%,#0000 60%,#000b);pointer-events:none}
.client-preview-label{position:absolute;z-index:1;top:15px;left:15px;padding:7px 9px;border:1px solid #ffffff40;border-radius:4px;background:#16151bba;color:#fff;font-size:7px;letter-spacing:1.6px;line-height:1.3}
.client-preview-handle{position:absolute;z-index:1;bottom:18px;left:19px;color:#fff;font-size:13px;letter-spacing:.1px;font-weight:500}
.project-visual.client-logo{background:radial-gradient(ellipse at 50% 40%,#24442d,#0d1912 80%);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:15px;padding:48px 20px}
.client-logo>img{width:106px;height:106px;object-fit:contain;filter:drop-shadow(0 8px 22px #11df0020)}
.client-preview-name{font-size:25px;letter-spacing:-.7px;color:#e8f7e8;line-height:1.1;z-index:1;font-weight:500}
.sample-image.sample-logo{width:160px;height:160px;object-fit:contain;display:block;margin:25px auto;background:#102016;border-radius:14px;padding:17px}
.sample-label a{text-decoration:underline;text-underline-offset:3px;color:#d2bfe8}
.card-links{flex-wrap:wrap;row-gap:10px}.card-links>a{overflow-wrap:anywhere}
@media(max-width:600px){.client-preview-label{font-size:7px}.client-preview-handle{font-size:14px}.project-visual.client-logo{gap:16px}.client-logo>img{width:120px;height:120px}}
```

## public/hero.css

```css
/* A personal, spacious hero inspired by the supplied reference. */
.portfolio-page{--hero-orange:#ff792d;--hero-ink:#171719;--hero-paper:#fafaf8}
.portfolio-page .site-header{background:#fafaf8f2;color:var(--hero-ink);border-color:#19191912}
.portfolio-page .site-header .wordmark span{color:var(--hero-orange)}
.portfolio-page .site-header nav{font-size:14px}
.portfolio-page .site-header .nav-contact{border-color:#222;background:#171719;color:#fff}
.portfolio-page .site-header .nav-contact:hover{background:#353539;color:#fff}
.portfolio-page .site-header nav>a:hover{color:#aa410c}
#scroll-progress{background:var(--hero-orange)}
.reference-hero{background:var(--hero-paper);color:var(--hero-ink);overflow:hidden;position:relative;isolation:isolate;padding-top:30px;color-scheme:light}
.reference-hero::before{content:"";position:absolute;inset:0;background-image:radial-gradient(#17171912 .6px,transparent .8px);background-size:5px 5px;opacity:.2;z-index:-1;pointer-events:none}
.hero-heading-wrap{position:relative;text-align:center;z-index:2}
.hello-tag{display:inline-block;position:relative;border:1px solid #262629;border-radius:999px;padding:7px 16px;font-size:14px;line-height:1.2;background:#fff}
.hello-tag svg{position:absolute;width:33px;height:33px;right:-28px;top:-24px;fill:none;stroke:var(--hero-orange);stroke-width:2;stroke-linecap:round;transform:rotate(20deg)}
.reference-hero h1{font-size:clamp(56px,6vw,84px);line-height:1.08;letter-spacing:-3.8px;font-weight:600;margin:13px 0 4px;color:var(--hero-ink)}
.reference-hero h1>span{background:none;color:var(--hero-orange);-webkit-text-fill-color:currentColor}
.reference-hero h1 .hero-wave{display:inline-block;font-size:.7em;margin-left:14px;vertical-align:8%;transform:rotate(-12deg);letter-spacing:0}
.hero-role{font-size:clamp(25px,3.1vw,42px);line-height:1.18;font-weight:500;letter-spacing:-1.5px;margin-inline:auto}
.hero-role>span{white-space:nowrap}
.hero-spark{position:absolute;width:66px;height:66px;left:13%;bottom:-43px;fill:none;stroke:var(--hero-orange);stroke-width:2;stroke-linecap:round;transform:rotate(15deg)}
.reference-hero .hero-composition{height:466px;min-height:0;position:relative;transform:none;margin:0 auto;width:min(1240px,calc(100% - 96px));isolation:isolate}
.hero-arc{position:absolute;z-index:-1;width:720px;height:360px;border-radius:720px 720px 0 0;background:#ffb16f;left:50%;bottom:0;transform:translateX(-50%);box-shadow:inset 0 1px #ffd4b5}
.reference-hero #scene-host{inset:auto;left:50%;top:-12px;bottom:auto;width:560px;height:490px;transform:translateX(-50%);z-index:0;pointer-events:none}
.reference-hero .scene-fallback{border-color:#ccc6c0;box-shadow:inset 7px 8px 15px #fff9,inset -15px -15px 17px #645648,17px 13px 34px #49250d40;opacity:1;top:16%}
.hero-statement{position:absolute;z-index:2;left:0;top:91px;max-width:239px;text-align:left}
.statement-mark{display:block;font-size:33px;line-height:1;color:var(--hero-orange);margin-bottom:17px}
.hero-statement p{font-size:18px;line-height:1.45;letter-spacing:-.4px}
.hero-statement strong{font-weight:600}
.hero-statement .statement-detail{font-size:14px;line-height:1.5;letter-spacing:0;margin-top:13px;max-width:229px;color:#5a5957}
.hero-experience{position:absolute;z-index:2;right:0;top:146px;max-width:225px;text-align:right}
.hero-experience>strong{font-size:42px;letter-spacing:-2px;line-height:1;font-weight:600}
.hero-experience p{font-size:14px;line-height:1.4;margin-top:9px}
.hero-experience>span{display:block;color:#62615e;font-size:12px;line-height:1.5;max-width:175px;margin:19px 0 0 auto}
.hero-skill{position:absolute;z-index:3;display:flex;align-items:center;gap:8px;border:1px solid #fff3;background:#171719;color:#fff;box-shadow:0 5px 0 #0000000a,0 10px 24px #0000000d;border-radius:999px;padding:9px 16px;font-size:14px;line-height:1.1;white-space:nowrap}
.hero-skill>span{color:#ffa860;font-size:17px;line-height:1}
.skill-social{left:24%;top:47px;transform:rotate(-8deg)}
.skill-copy{right:22%;top:76px;transform:rotate(9deg)}
.skill-design{left:25%;top:261px;transform:rotate(6deg)}
.skill-strategy{right:23%;top:292px;transform:rotate(-8deg)}
.hero-action-pill{position:absolute;z-index:4;left:50%;bottom:38px;transform:translateX(-50%);display:flex;align-items:center;background:#222126e8;padding:6px;border:1px solid #ffffff6b;border-radius:999px;gap:4px;box-shadow:0 9px 24px #4f270a22;backdrop-filter:blur(14px);white-space:nowrap}
.hero-action-pill>a,.hero-action-pill>button{font-size:15px;line-height:1.2;border:0;padding:12px 21px;border-radius:999px;font-weight:500}
.hero-action-pill>a{background:var(--hero-orange);color:#161412;display:flex;gap:18px;align-items:center}
.hero-action-pill>a:hover{background:#ffa25d}
.hero-action-pill>button{color:#fff}.hero-action-pill>button:hover{background:#ffffff18}
.reference-hero .motion-toggle{top:auto;right:0;bottom:23px;background:#fff9;border:1px solid #cecbc6;color:#57534f;font-size:12px;padding:8px 12px;gap:6px}
.reference-hero a:focus-visible,.reference-hero button:focus-visible,.site-header a:focus-visible,.site-header button:focus-visible{outline-color:#b9450b}
.portfolio-page .client-ribbon{margin-top:0;padding-block:25px}
@media(min-width:1500px){.reference-hero{padding-top:41px}.reference-hero .hero-composition{height:490px}}
@media(max-width:1100px){.hero-statement{max-width:191px;top:108px}.hero-statement p{font-size:16px}.hero-statement .statement-detail{font-size:13px}.hero-experience{max-width:175px}.hero-experience>strong{font-size:36px}.hero-arc{width:600px;height:300px}.reference-hero #scene-host{width:495px;height:466px;top:-10px}.skill-social{left:21%;top:54px}.skill-copy{right:15%;top:72px}.skill-design{left:22%;top:272px}.skill-strategy{right:20%;top:287px}.hero-spark{left:5%}}
@media(max-width:800px){.reference-hero{padding-top:26px}.reference-hero .hero-composition{width:calc(100% - 40px);height:530px}.reference-hero h1{font-size:65px;letter-spacing:-3px}.hero-role{font-size:31px;max-width:600px;letter-spacing:-1px}.hero-arc{width:560px;height:280px}.reference-hero #scene-host{top:24px;width:475px;height:442px}.hero-statement{max-width:190px;top:auto;bottom:33px}.hero-statement p{font-size:14px}.hero-statement .statement-detail{display:none}.statement-mark{font-size:24px;margin-bottom:9px}.hero-experience{top:85px;max-width:143px}.hero-experience>strong{font-size:31px}.hero-experience p{font-size:12px}.hero-experience>span{display:none}.skill-social{left:8%;top:35px}.skill-copy{right:4%;top:191px}.skill-design{left:7%;top:220px}.skill-strategy{right:14%;top:337px}.hero-action-pill{bottom:80px}.hero-spark{left:5%;bottom:-31px;width:45px}.reference-hero .motion-toggle{bottom:30px}}
@media(max-width:600px){.portfolio-page .site-header nav{font-size:12px;gap:15px}.portfolio-page .site-header .nav-contact{padding:10px 13px}.portfolio-page .site-header .nav-contact span{margin-left:7px}.reference-hero{padding-top:25px}.reference-hero h1{font-size:clamp(45px,12vw,65px);letter-spacing:-2.4px;margin:18px 0 9px}.reference-hero h1 .hero-wave{margin-left:8px}.hello-tag{font-size:12px;padding:6px 13px}.hello-tag svg{width:27px;height:27px;right:-24px;top:-20px}.hero-role{font-size:clamp(23px,6.3vw,32px);max-width:350px;letter-spacing:-.7px;line-height:1.15}.hero-role>span{display:block}.hero-spark{width:36px;height:36px;left:1%;bottom:-36px}.reference-hero .hero-composition{width:calc(100% - 32px);height:536px;min-height:0;margin-top:0}.hero-arc{width:410px;height:220px;bottom:72px}.reference-hero #scene-host{top:44px;width:385px;height:375px;max-width:calc(100% + 25px)}.hero-skill{font-size:12px;padding:8px 12px;gap:6px}.hero-skill>span{font-size:14px}.skill-social{left:2%;top:41px}.skill-copy{right:1%;top:100px}.skill-design{left:0;top:224px}.skill-strategy{right:0;top:286px}.hero-action-pill{bottom:106px;padding:5px}.hero-action-pill>a,.hero-action-pill>button{font-size:14px;padding:12px 19px}.hero-statement{left:2px;top:auto;bottom:24px;width:55%;max-width:185px}.hero-statement p{font-size:13px;line-height:1.5;letter-spacing:-.2px}.statement-mark{font-size:23px;margin-bottom:8px}.hero-experience{top:auto;bottom:28px;right:3px;width:42%;max-width:146px}.hero-experience>strong{font-size:29px;letter-spacing:-1.2px}.hero-experience p{font-size:12px;margin-top:7px;line-height:1.35}.reference-hero .motion-toggle{bottom:176px;right:50%;transform:translateX(50%);font-size:12px;padding:6px 10px;background:#ffffffb5}.portfolio-page .client-ribbon{padding-block:20px}.portfolio-page .client-ribbon>p{font-size:12px;letter-spacing:1px}.portfolio-page #client-ribbon button{font-size:13px}.reference-hero .scene-fallback{border-width:35px}}
@media(prefers-reduced-motion:reduce){.reference-hero *{scroll-behavior:auto}}

.portfolio-page .client-ribbon>p{font-size:12px;letter-spacing:1px}
.portfolio-page #client-ribbon button{font-size:14px}
@media(max-width:600px){
 .reference-hero .hero-composition{height:575px}
 .hero-arc{bottom:130px}
 .hero-action-pill{bottom:132px}
 .hero-statement{top:467px;bottom:auto}
 .hero-experience{top:462px;bottom:auto}
 .reference-hero .motion-toggle{top:344px;bottom:auto}
 .portfolio-page #client-ribbon button{font-size:13px}
}
```

## public/theme.css

```css
/* Shared light/orange identity, extending the hero to every portfolio surface. */
:root{
  --bg:#fafaf8;--panel:#ffffff;--text:#171719;--muted:#605e59;--line:#deddd7;
  --brand-orange:#ff792d;--brand-peach:#ffb16f;--brand-soft:#fff0e4;
  --accent-ink:#9d3e0c;--purple:#a7430e;--error:#a32925;
  --hero-orange:var(--brand-orange);--hero-ink:var(--text);--hero-paper:var(--bg);
  color-scheme:light;
}
body,.portfolio-page{background:var(--bg);color:var(--text)}
.site-header{background:#fafaf8f2;color:var(--text);border-color:var(--line)}
.site-header .wordmark span,.footer .wordmark span{color:var(--brand-orange)}
.site-header nav{font-size:14px}.site-header nav a:hover{color:var(--accent-ink)}
.button{font-size:14px;font-weight:600;padding:15px 24px;gap:22px}
.primary{background:var(--brand-orange);color:#171719;box-shadow:none}
.primary:hover{background:#ffa360;box-shadow:0 6px 20px #e367181a}
.secondary{border-color:#c6c2bb;background:#fff;color:var(--text)}
.secondary:hover{background:var(--brand-soft);border-color:#e5a06e}
.wordmark{color:var(--text)}
.skip-link{background:var(--brand-orange);color:#171719}
.draft-banner{background:#ffe3cb;color:var(--text);font-size:14px}
.eyebrow{font-size:12px;letter-spacing:1.7px;color:var(--accent-ink)}
/* A continuous transition from the orange hero into selected work. */
.portfolio-page .client-ribbon{border-color:var(--line);background:transparent}
.portfolio-page .client-ribbon>p{color:var(--muted);font-size:12px;min-width:145px}
.portfolio-page #client-ribbon button{color:#373532;font-size:14px}
.portfolio-page #client-ribbon button:hover{color:var(--accent-ink)}
.work-section{padding-top:78px}
.section-heading{gap:36px;margin-bottom:35px}
.section-heading .eyebrow{font-size:12px;color:var(--accent-ink);margin-bottom:18px}
.section-heading h2{font-size:clamp(34px,3.6vw,49px);font-weight:500;letter-spacing:-1.8px}
h2>span{color:var(--accent-ink)}
.section-heading>p{font-size:16px;line-height:1.6;color:var(--muted);max-width:330px}
.work-controls{border-color:var(--line);gap:16px;flex-wrap:wrap}
.filter{border-color:#d3d0c8;color:#4f4c47;background:#fff;font-size:14px;padding:10px 16px}
.filter:hover{border-color:#c45619;color:var(--accent-ink)}
.filter.active{background:#171719;color:#fff;border-color:#171719}
.filter.active span{color:#ffba84;opacity:1}
.filter span{font-size:12px}
.client-filter select,.industry-filter select{background:#fff;color:var(--text);border:1px solid #d3d0c8;border-radius:9px;font-size:14px;padding:12px;max-width:235px}
.project-search{background:#fff;border-color:#d3d0c8;border-radius:9px;min-width:0}
.project-search>span{color:var(--accent-ink)}
.project-search input{font-size:14px;color:var(--text);padding:14px 0}
.project-search input::placeholder{color:#706b63;opacity:1}
.edit-clients-link{font-size:13px;color:var(--accent-ink);padding:10px 0}
.edit-clients-link:hover{color:#171719;text-decoration:underline}
.work-meta{color:var(--muted);font-size:12px;margin-block:23px 17px;align-items:center}
.work-meta>span:last-child{font-size:12px;letter-spacing:.5px}
.project-grid{gap:25px}
.project-card{background:#fff;border:1px solid #dedbd5;border-radius:17px;padding:10px 10px 20px;box-shadow:0 5px 20px #29211404}
.project-card:hover{border-color:#e0a67f;box-shadow:0 15px 35px #8c491b12}
.project-card::after{background:radial-gradient(circle at var(--shine-x,50%) var(--shine-y,0%),#ffb16f0c,transparent 60%)}
.project-visual{border-radius:10px}
.project-info{padding:20px 9px 0}
.project-info h3{font-size:19px;font-weight:600;letter-spacing:-.4px;line-height:1.25}
.project-info p{font-size:12px;color:var(--muted);margin-top:7px;line-height:1.5}
.project-card .open-arrow{border-color:#e1c9b6;background:#fff1e6;color:#9d3e0c;width:35px;height:35px}
.project-open:hover .open-arrow{background:var(--brand-orange);border-color:var(--brand-orange);color:#171719}
.project-tags{padding-inline:9px;gap:6px;margin-top:16px}
.project-tags span{font-size:12px;letter-spacing:0;color:#5a5048;background:#f5f2ed;border:1px solid #ece5dc;border-radius:999px;padding:5px 9px;line-height:1.2}
.project-tags span:not(:last-child){margin-right:0}
.project-description{font-size:14px;line-height:1.65;color:#5c5851;margin:14px 9px 0;min-height:69px}
.card-links{font-size:13px;gap:18px;padding:17px 9px 0}
.card-links>a{color:var(--accent-ink);font-weight:500}.card-links>span{color:var(--muted)}
.client-preview-label{font-size:10px;letter-spacing:1px;padding:7px 9px}
.client-preview-handle{font-size:14px}
.work-disclaimer{font-size:12px;color:#67615a;line-height:1.65;max-width:850px}
.empty-state{background:#fff;border-color:var(--line);border-radius:16px}
.empty-state h3{font-size:24px}.empty-state p{font-size:16px}
/* Skills and profile use the same paper, ink, and orange vocabulary. */
.about-section{padding-top:95px}
.about-grid{gap:55px}
.profile-panel{background:#fff0e4;border:1px solid #f0d5bc;border-radius:20px;padding:34px}
.monogram{background:var(--brand-orange);color:#171719;box-shadow:4px 5px 0 #efb88b,8px 12px 23px #d8905715}
.monogram span{color:#171719}
.profile-panel>.eyebrow{font-size:12px;color:var(--accent-ink)}
.profile-panel h3{font-size:36px;letter-spacing:-1.2px}
.profile-panel>p:not(.eyebrow){font-size:16px;line-height:1.7;color:#574b43;max-width:none}
.experience{border-color:#e4cbb8;margin-top:27px}
.experience>span,.education>span{font-size:12px;color:var(--accent-ink);letter-spacing:1px}
.experience strong{font-size:16px;font-weight:600}
.experience p,.education p{font-size:14px;color:#574b43;line-height:1.6}
.capability-row{border-color:var(--line);padding-block:27px 30px}
.row-number{font-size:14px;color:var(--accent-ink)}
.capability-row h3{font-size:25px;font-weight:500;letter-spacing:-.7px}
.capability-row p{font-size:16px;color:var(--muted);line-height:1.7;max-width:570px}
.skill-tags{gap:7px}
.skill-tags span{background:#fff;border:1px solid #ded8cf;color:#555049;font-size:12px;line-height:1.3;padding:7px 10px;border-radius:999px}
.tools-block>.eyebrow{font-size:12px;color:var(--accent-ink)}
.tool-list{gap:9px}
.tool-list>span{font-size:14px;font-weight:500;background:#fff1e6;border:1px solid #f2d5be;border-radius:8px;padding:9px 12px;line-height:1.3}
.tools-block>p:last-child{font-size:14px;color:var(--muted);line-height:1.6}
.contact-panel{background:#ffb16f;border:1px solid #f5a965;border-radius:24px;padding:43px 45px;margin-top:70px}
.contact-panel .eyebrow{font-size:12px;color:#673519;letter-spacing:1.2px}
.contact-panel h2{font-size:clamp(32px,3.4vw,44px);letter-spacing:-1.6px}
.contact-panel h2>span{color:#171719}
.contact-panel .primary{background:#171719;color:#fff;min-width:160px}
.contact-panel .primary:hover{background:#37302b}
.footer{margin-top:35px;border-color:var(--line);padding-block:28px 34px}
.footer p,.footer>div{font-size:13px;color:#625c55}
.footer a:hover{color:var(--accent-ink)}
/* Project and contact overlays stay consistent with the light page. */
dialog{background:#fff;border:1px solid #d8cec2;color:var(--text);border-radius:20px;box-shadow:0 25px 80px #241a1426}
dialog::backdrop{background:#19161088;backdrop-filter:blur(7px)}
.dialog-close{background:#fff;border-color:#d9c9b9;color:#171719;width:38px;height:38px}
.dialog-close:hover{background:var(--brand-soft)}
.dialog-header{background:#fff0e4;border-color:#ead7c6}
.dialog-header .eyebrow{font-size:12px;color:var(--accent-ink);letter-spacing:1.3px}
.dialog-header h2{font-size:36px}
.dialog-header>p:not(.eyebrow){font-size:16px;line-height:1.6;color:#605347}
.dialog-deliverables{gap:7px;margin-top:18px}
.dialog-deliverables>span{background:#fff;border:1px solid #e9c9b1;border-radius:999px;color:#6a4329;font-size:12px;padding:6px 10px;line-height:1.3}
.dialog-facts{background:#f8f6f2;border-color:#e5e0d8}
.dialog-facts h3{font-size:12px;color:var(--accent-ink);letter-spacing:1px}
.dialog-facts p{font-size:14px;color:#524e48}
.detail-block h3{font-size:12px;color:var(--accent-ink);letter-spacing:1.2px}
.detail-block p,.detail-block li{font-size:15px;color:#504a43;line-height:1.7}
.sample-box{background:#ffe2c8;color:#302219;border:1px solid #f3cba9;border-radius:12px;font-size:24px;line-height:1.35}
.sample-label{font-size:12px!important;line-height:1.6!important;color:#696158!important}
.sample-label a{color:var(--accent-ink)}
.project-links a{border-color:#ddc9b8;background:#fff7ef;color:var(--accent-ink);font-size:13px;line-height:1.4;padding:9px 12px}
.project-links a:hover{background:#ffe3cb;border-color:#d8935f}
.dialog-note{font-size:12px;color:#696158;line-height:1.65}
.sample-pending{background:#fff5eb;border-color:#eacbad}.sample-pending>span{color:#ad4c11}
#contact-dialog{background:#fff8f1}
.contact-dialog-content>.eyebrow{font-size:12px;color:var(--accent-ink);letter-spacing:1px}
.contact-dialog-content h2>span{color:#ce5817}
#contact-description{font-size:16px;color:#64584d;line-height:1.6}
.contact-email{color:var(--accent-ink);border-color:#dfcbb7}
.contact-email:hover{color:#171719}
.contact-actions .button{font-size:14px;gap:12px;padding:13px 18px}
#copy-status{font-size:14px;color:#30643a}
/* The client editor follows the same theme. */
.editor-main{max-width:1050px}
.editor-main h1{color:var(--text)}
.editor-main .editor-intro{font-size:16px;color:var(--muted);line-height:1.7}
.editor-notice{background:#fff0e4;border-color:var(--brand-orange);color:#6a4a34;font-size:14px}
.editor-status{font-size:14px;color:#85502c}
.editor-section{background:#fff;border:1px solid var(--line);border-radius:16px}
.editor-section h2{font-size:27px}
.editor-project{border-color:#ded8cf;background:#fff;border-radius:11px}
.editor-project summary{font-size:16px;color:#292521;padding:20px}
.editor-project summary::marker{color:#c35b1a}
.editor-project[open] summary{background:#fff4e9;border-color:#e8d4c1;color:#8f3e0d;border-radius:10px 10px 0 0}
.editor-layout-nav>a{font-size:14px;color:var(--accent-ink)}
.field{font-size:14px;color:#4c453d}
.field input,.field textarea,.field select{background:#fff;color:var(--text);border-color:#cfc7bd;border-radius:7px;font-size:15px}
.field input:focus,.field textarea:focus,.field select:focus{border-color:#b34e10}
.field small{font-size:12px;color:#71665b}
.image-upload{background:#fff8f1;border-color:#d5a27c}
.image-upload input{font-size:14px}
.editor-remove{border-color:#d5b0a2;color:#993b24;background:#fff6f2;font-size:13px}
.editor-footer-note,.editor-note{font-size:14px;color:#6d6257}
@media(max-width:1100px){
  .discovery-row{flex-wrap:wrap}.project-search{flex:1 1 360px}.about-grid{gap:35px}
  .project-info h3{font-size:18px}.project-tags span{font-size:12px}
  .card-links{gap:12px}.contact-panel{padding:35px}
}
@media(max-width:800px){
  .section-heading{align-items:flex-start;gap:25px}.section-heading>p{max-width:245px;font-size:15px}
  .project-search{flex:1 1 100%}.edit-clients-link{margin-left:auto}
  .profile-panel{padding:26px}.about-grid{grid-template-columns:1fr;gap:35px}
  .profile-panel>p:not(.eyebrow){max-width:620px}.tools-block{padding-left:35px}
  .capability-row{grid-template-columns:22px 1fr}.contact-panel{padding:34px}
  .footer>div{font-size:13px}.editor-toolbar .button{font-size:14px}
}
@media(max-width:600px){
  .work-section{padding-top:50px}.section-heading{margin-bottom:29px}
  .section-heading h2{font-size:35px;letter-spacing:-1.25px}.section-heading .eyebrow{font-size:12px;line-height:1.6}
  .section-heading>p{font-size:16px;max-width:none;margin-top:20px}
  .filter-buttons{gap:7px}.filter{font-size:13px;padding:9px 13px}
  .client-filter select{max-width:none;width:100%;font-size:14px;padding:13px}
  .industry-filter select{width:100%;max-width:none;font-size:14px;padding:12px}
  .industry-filter{flex:1 1 100%}.edit-clients-link{margin-left:0;font-size:14px;padding:4px 0}
  .project-search{flex-basis:100%}.project-search input{font-size:14px}
  .work-meta{font-size:12px;align-items:flex-start}.work-meta>span:last-child{font-size:12px;letter-spacing:0;max-width:170px;text-align:right;line-height:1.5}
  .project-grid{gap:22px}.project-card{padding:9px 9px 19px}
  .project-info h3{font-size:20px}.project-info p{font-size:13px}
  .project-description{font-size:15px;min-height:0}.card-links{font-size:14px;padding-top:16px}
  .client-preview-label{font-size:10px}.client-preview-handle{font-size:14px}
  .work-disclaimer{font-size:12px}.about-section{padding-top:65px}
  .profile-panel{padding:28px}.profile-panel h3{font-size:34px}
  .capability-row h3{font-size:25px}.capability-row p{font-size:16px}
  .tools-block{padding-left:35px}.skill-tags span{font-size:12px}
  .contact-panel{margin-top:40px;padding:30px 24px;border-radius:19px;gap:24px}
  .contact-panel h2{font-size:33px;letter-spacing:-1.2px}.contact-panel .eyebrow{font-size:12px;line-height:1.6}
  .footer{margin-top:24px}.footer>div{gap:16px;font-size:13px}
  .dialog-header{padding:44px 24px 25px}.dialog-header h2{font-size:30px;line-height:1.15}
  .dialog-header .eyebrow{font-size:12px}.dialog-header>p:not(.eyebrow){font-size:16px}
  .dialog-close{width:34px;height:34px}.dialog-facts{padding:22px 24px}
  .dialog-body{padding:25px 24px;gap:27px}.detail-block p,.detail-block li{font-size:16px}
  .contact-dialog-content{padding:45px 22px 24px}.contact-dialog-content>.eyebrow{font-size:12px}
  .contact-email{font-size:17px;letter-spacing:-.5px}.contact-actions .button{font-size:13px;padding:12px 14px}
  .editor-main .editor-intro{font-size:16px}.editor-notice{font-size:14px}
  .editor-fields{grid-template-columns:1fr}.editor-toolbar .button{font-size:14px;padding:13px 17px}
  .editor-layout-nav{flex-wrap:wrap}.editor-project summary{font-size:16px}.editor-project .editor-fields{padding:18px}
}
```

## public/app.js

```javascript
import { loadData, esc, safeUrl, safeImage } from './data.js';
import './motion.js';
const grid=document.querySelector('#project-grid'),select=document.querySelector('#client-select'),category=document.querySelector('#category-select'),search=document.querySelector('#project-search'),dialog=document.querySelector('#project-dialog'),more=document.querySelector('#show-more');
let projects=[],activeFilter='All',expanded=false;
const themes=['iron','clique','ascend','noah','refuge','pov','eclipse','health','scholar','merge','property'];
function instagramLabel(url) {
  const safe=safeUrl(url,true);if(!safe)return 'Instagram';
  const parts=new URL(safe).pathname.split('/').filter(Boolean);
  return parts.length===1&&!['p','reel','reels','stories','explore'].includes(parts[0])?'@'+parts[0]:'Instagram';
}
function visual(p) {
  const theme=themes.includes(p.theme)?p.theme:'clique',img=safeImage(p.image);
  if(img&&p.imageKind==='client'){
    const position=['top','center','bottom'].includes(p.imagePosition)?p.imagePosition:'center';
    return `<div class="project-visual client-preview${p.imageFit==='contain'?' client-logo':''} focus-${position}"><img src="${esc(img)}" alt="${esc(p.imageLabel||p.name+' client image')}" loading="lazy"><span class="client-preview-label">CLIENT PROFILE</span>${p.imageFit==='contain'?`<strong class="client-preview-name">${esc(p.name)}</strong>`:''}<span class="client-preview-handle">${esc(instagramLabel(p.instagram))}</span></div>`;
  }
  if(img)return `<div class="project-visual theme-iron"><img src="${esc(img)}" alt="${esc(p.imageLabel||p.name+' work sample')}" loading="lazy"></div>`;
  return `<div class="project-visual theme-${theme}"><span class="visual-brand">${esc(p.name.toUpperCase())}</span><span class="visual-decoration" aria-hidden="true"></span><span class="visual-headline">${esc(p.headline)}</span><span class="visual-caption">${p.formats.length?esc(p.formats.slice(0,2).join(' / ').toUpperCase())+' · ':''}PORTFOLIO TREATMENT</span></div>`;
}
function link(url,label,instagram=false){const safe=safeUrl(url,instagram);return safe?`<a href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${esc(label)} ↗</a>`:''}
function render() {
  const term=search.value.trim().toLowerCase();
  const filtered=projects.filter(p=>(activeFilter==='All'||p.formats.includes(activeFilter))&&(!select.value||p.id===select.value)&&(!category.value||p.category===category.value)&&(!term||[p.name,p.industry,p.summary,p.role,p.category,...p.formats,...(p.deliverables||[])].join(' ').toLowerCase().includes(term)));
  const limited=!expanded&&activeFilter==='All'&&!select.value&&!category.value&&!term;
  const shown=limited?filtered.slice(0,6):filtered;
  grid.innerHTML=shown.map(p=>`<article class="project-card"><button class="project-open" data-id="${esc(p.id)}" aria-label="Explore ${esc(p.name)}">${visual(p)}<div class="project-info"><div><h3>${esc(p.name)}</h3><p>${esc(p.industry)}</p></div><span class="open-arrow" aria-hidden="true">↗</span></div></button><div class="project-tags">${p.formats.map(f=>`<span>${esc(f)}</span>`).join('')}</div><p class="project-description">${esc(p.summary)}</p><div class="card-links">${link(p.instagram,instagramLabel(p.instagram),true)}${link(p.website,'Website')}${!p.instagram&&!p.website?'<span>Explore the project for work details</span>':''}</div></article>`).join('');
  document.querySelector('#result-count').textContent=`${String(shown.length).padStart(2,'0')}${shown.length<filtered.length?' of '+filtered.length:''} projects${activeFilter==='All'?'':' · '+activeFilter}`;
  document.querySelector('#empty-state').hidden=filtered.length>0;
  more.hidden=shown.length>=filtered.length;more.textContent=`Explore ${filtered.length-shown.length} more clients ↓`;
  document.querySelectorAll('.filter').forEach(b=>{const on=b.dataset.filter===activeFilter;b.classList.toggle('active',on);b.setAttribute('aria-pressed',on)});
}
function openProject(id) {
  const p=projects.find(p=>p.id===id);if(!p)return;
  const img=safeImage(p.image);
  const imageCaption=p.imageKind==='client'?`Client imagery${safeUrl(p.imageSource)?' · '+link(p.imageSource,'Image source'):''}`:`${esc(p.imageLabel)}. Portfolio creative; no claim of publication or campaign results.`;
  const facts=`<div class="dialog-facts"><div><h3>Industry & platforms</h3><p>${esc(p.category||p.industry)}${p.platforms?.length?'<br>'+p.platforms.map(esc).join(' · '):''}</p></div>${p.audience?`<div><h3>The audience</h3><p>${esc(p.audience)}</p></div>`:''}</div>`;
  const details=(p.role?`<div class="detail-block"><h3>My role</h3><p>${esc(p.role)}</p></div>`:'')+(p.responsibilities.length?`<div class="detail-block"><h3>Responsibilities</h3><ul>${p.responsibilities.map(r=>`<li>${esc(r)}</li>`).join('')}</ul></div>`:'')+(p.approach?`<div class="detail-block"><h3>The approach</h3><p>${esc(p.approach)}</p></div>`:'');
  document.querySelector('#dialog-content').innerHTML=`<div class="dialog-header"><p class="eyebrow">${esc(p.industry.toUpperCase())}</p><h2 id="dialog-title">${esc(p.name)}</h2><p>${esc(p.summary)}</p><div class="dialog-deliverables">${(p.deliverables||[]).map(x=>`<span>${esc(x)}</span>`).join('')}</div></div>${facts}<div class="dialog-body"><div>${details||'<div class="detail-block"><h3>Project details</h3><p>Details will be added alongside the work samples.</p></div>'}<div class="project-links">${link(p.instagram,'Instagram profile / post',true)}${link(p.website,'Client website')}${p.examples.map(e=>link(e.url,e.label)).join('')}</div>${p.instagram?'<p class="dialog-note">The profile link provides client context. It does not imply authorship of every post.</p>':''}</div><div>${p.example?`<div class="detail-block"><h3>Content example</h3><div class="sample-box">${esc(p.example)}</div><p class="sample-label">${esc(p.exampleType)} · reformatted for this portfolio.</p></div>`:!img?'<div class="sample-pending"><span aria-hidden="true">✳</span><h3>Work samples coming soon.</h3></div>':''}${img?`<img class="sample-image${p.imageKind==='client'&&p.imageFit==='contain'?' sample-logo':''}" src="${esc(img)}" alt="${esc(p.imageLabel||p.name+' work sample')}"><p class="sample-label">${imageCaption}</p>`:''}</div></div>`;
  dialog.showModal();dialog.scrollTop=0;
}
function reset(){activeFilter='All';select.value='';category.value='';search.value='';expanded=false;render()}
document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{activeFilter=b.dataset.filter;expanded=false;render()}));
select.addEventListener('change',render);category.addEventListener('change',render);search.addEventListener('input',render);
more.addEventListener('click',()=>{expanded=true;render();grid.querySelectorAll('.project-open')[6]?.focus({preventScroll:true})});
document.querySelector('#reset-filters').addEventListener('click',reset);
grid.addEventListener('click',event=>{const button=event.target.closest('[data-id]');if(button)openProject(button.dataset.id)});
document.querySelector('#client-ribbon').addEventListener('click',event=>{const b=event.target.closest('[data-project]');if(b)openProject(b.dataset.project)});
dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close()}});
const contactDialog=document.querySelector('#contact-dialog');
document.querySelectorAll('[data-contact]').forEach(button=>button.addEventListener('click',()=>{document.querySelector('#copy-status').textContent='';contactDialog.showModal()}));
contactDialog.querySelector('.dialog-close').addEventListener('click',()=>contactDialog.close());
contactDialog.addEventListener('click',event=>{if(event.target===contactDialog){const r=contactDialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)contactDialog.close()}});
document.querySelector('#copy-email').addEventListener('click',async()=>{
  const email=document.querySelector('#contact-email').textContent;
  try{await navigator.clipboard.writeText(email);document.querySelector('#copy-status').textContent='Email copied.'}
  catch{const selection=getSelection(),range=document.createRange();range.selectNodeContents(document.querySelector('#contact-email'));selection.removeAllRanges();selection.addRange(range);document.querySelector('#copy-status').textContent='Email selected. Use your device’s copy command.'}
});
try {
  const draft=new URLSearchParams(location.search).get('draft')==='1';document.querySelector('#draft-banner').hidden=!draft;
  const data=await loadData(draft);projects=data.projects;
  document.querySelectorAll('[data-name]').forEach(n=>n.textContent=data.profile.name);
  document.querySelectorAll('[data-location]').forEach(n=>n.textContent=data.profile.location||'');
  document.querySelector('[data-bio]').textContent=data.profile.bio||'';
  document.querySelectorAll('[data-email]').forEach(a=>a.href=`mailto:${encodeURIComponent(data.profile.email||'')}`);
  document.querySelector('#contact-email').textContent=data.profile.email||'aniketpathania68393@gmail.com';
  const linkedin=safeUrl(data.profile.linkedin);if(linkedin){const a=document.querySelector('#linkedin-link');a.href=linkedin;a.hidden=false}
  select.innerHTML='<option value="">All clients</option>'+projects.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  category.innerHTML='<option value="">All industries</option>'+[...new Set(projects.map(p=>p.category).filter(Boolean))].sort().map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
  document.querySelector('#total-count').textContent=String(projects.length).padStart(2,'0');document.querySelector('#client-total').textContent=projects.length;
  const featured=projects.slice(0,5);
  document.querySelector('#client-ribbon').innerHTML=featured.map(p=>`<button data-project="${esc(p.id)}">${esc(p.name)}</button>`).join('');
  render();
} catch(error){document.querySelector('#result-count').textContent=error.message;grid.innerHTML='<p>Project details are temporarily unavailable. Please reload this page.</p>';}
```

## public/data.js

```javascript
export const DRAFT_KEY = 'aniket-portfolio-draft-v1';
export const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function safeUrl(value, instagram = false) {
  if (!value) return '';
  try {const u = new URL(value); if (u.protocol !== 'https:') return ''; if (instagram && !['instagram.com','www.instagram.com'].includes(u.hostname)) return ''; return u.href;} catch {return '';}
}
export function safeImage(value) {
  if (!value) return '';
  if (typeof value==='string' && value.length<1500000 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value)) return value;
  if (/^assets\/[a-zA-Z0-9_./-]+\.(jpg|jpeg|png|webp|svg)$/i.test(value) && !value.includes('..')) return value;
  return safeUrl(value);
}
export function validateData(data) {
  if (!data || !data.profile || typeof data.profile.name !== 'string' || !Array.isArray(data.projects)) throw new Error('Use a portfolio JSON file exported from this editor.');
  if (data.projects.length > 100) throw new Error('Please keep the portfolio under 100 projects.');
  const ids = new Set();
  for (const p of data.projects) {
    if (!p || typeof p.id !== 'string' || !p.id || ids.has(p.id) || typeof p.name !== 'string' || !p.name.trim()) throw new Error('Every project needs a unique ID and a client name.');
    ids.add(p.id);
    for(const key of ['platforms','deliverables']) if(p[key]!==undefined&&(!Array.isArray(p[key])||p[key].some(x=>typeof x!=='string'))) throw new Error(`${p.name}: ${key} must be a list of text.`);
    if(p.audience!==undefined&&typeof p.audience!=='string') throw new Error(`${p.name}: audience must be text.`);
    for (const key of ['formats','responsibilities','examples']) if (!Array.isArray(p[key])) throw new Error(`${p.name}: ${key} must be a list.`);
    if (p.formats.some(x=>typeof x !== 'string') || p.responsibilities.some(x=>typeof x !== 'string') || p.examples.some(x=>!x || typeof x.label !== 'string' || typeof x.url !== 'string')) throw new Error(`${p.name}: invalid project details.`);
    for(const key of ['industry','category','theme','headline','summary','role','approach','exampleType','example','image','imageLabel','instagram','website']) if (typeof p[key] !== 'string') throw new Error(`${p.name}: ${key} must be text.`);
    if(p.instagram && !safeUrl(p.instagram,true)) throw new Error(`${p.name}: enter a valid https Instagram profile or post URL.`);
    if(p.website && !safeUrl(p.website)) throw new Error(`${p.name}: enter a valid https website URL.`);
    if(p.examples.some(x=>!safeUrl(x.url))) throw new Error(`${p.name}: example links must use https.`);
    for(const [key,allowed] of Object.entries({imageKind:['','work','client'],imageFit:['','cover','contain'],imagePosition:['','top','center','bottom']})) if(p[key]!==undefined&&!allowed.includes(p[key])) throw new Error(`${p.name}: choose a valid ${key}.`);
    if(p.imageSource!==undefined&&(typeof p.imageSource!=='string'||(p.imageSource&&!safeUrl(p.imageSource)))) throw new Error(`${p.name}: image source must be an HTTPS URL.`);
    if(p.image && !safeImage(p.image)) throw new Error(`${p.name}: upload an image or use an assets path or HTTPS image URL.`);
  }
  if (data.profile.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.profile.email)) throw new Error('Enter a valid contact email.');
  if (data.profile.linkedin && !safeUrl(data.profile.linkedin)) throw new Error('Enter a valid https LinkedIn URL.');
  return data;
}
export async function loadData(draft = false) {
  if (draft) {try {const saved = localStorage.getItem(DRAFT_KEY); if(saved) return validateData(JSON.parse(saved));} catch(error) {console.warn('Draft could not load:',error.message);}}
  const response = await fetch('portfolio-data.json', {cache:'no-cache'});
  if(!response.ok) throw new Error('Could not load the portfolio. Please reload the page.');
  return validateData(await response.json());
}
```

## public/motion.js

```javascript
export const motion = {enabled: !matchMedia('(prefers-reduced-motion: reduce)').matches};
const pref=matchMedia('(prefers-reduced-motion: reduce)');
try{const saved=localStorage.getItem('aniket-motion');if(saved!==null)motion.enabled=saved==='on'&&!pref.matches;}catch{}
const toggle=document.querySelector('#motion-toggle');
function apply(){
  document.body.classList.toggle('motion-off',!motion.enabled);
  if(toggle){toggle.setAttribute('aria-pressed',String(motion.enabled));toggle.innerHTML=`<span aria-hidden="true">${motion.enabled?'Ⅱ':'▷'}</span> Motion ${motion.enabled?'on':'off'}`;}
  if(!motion.enabled)document.querySelectorAll('.project-card').forEach(c=>{c.style.removeProperty('--tilt-x');c.style.removeProperty('--tilt-y');});
  window.dispatchEvent(new Event('portfolio-motion'));
}
toggle?.addEventListener('click',()=>{motion.enabled=!motion.enabled;try{localStorage.setItem('aniket-motion',motion.enabled?'on':'off');}catch{}apply();});
pref.addEventListener('change',()=>{motion.enabled=!pref.matches;apply();});apply();

const grid=document.querySelector('#project-grid');
grid?.addEventListener('pointermove',e=>{
  const card=e.target.closest('.project-card');if(!card||!motion.enabled||e.pointerType==='touch')return;
  const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
  card.style.setProperty('--tilt-x',`${(y-.5)*-5}deg`);card.style.setProperty('--tilt-y',`${(x-.5)*6}deg`);
  card.style.setProperty('--shine-x',`${x*100}%`);card.style.setProperty('--shine-y',`${y*100}%`);
});
grid?.addEventListener('pointerout',e=>{const card=e.target.closest('.project-card');if(card&&!card.contains(e.relatedTarget)){card.style.removeProperty('--tilt-x');card.style.removeProperty('--tilt-y');}});
const progress=document.querySelector('#scroll-progress');
let ticking=false;
function updateProgress(){const max=document.documentElement.scrollHeight-innerHeight;if(progress)progress.style.transform=`scaleX(${max>0?scrollY/max:0})`;ticking=false;}
window.addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(updateProgress);}},{passive:true});

const host=document.querySelector('#scene-host');
if(host){import('./scene.js').then(({mountScene})=>mountScene(host,motion)).catch(()=>{host.dataset.render='fallback';});}
```

## public/edit.html

```html
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Edit portfolio — Aniket</title><meta name="robots" content="noindex,nofollow"><link rel="icon" href="assets/favicon.svg"><link rel="stylesheet" href="styles.css"><link rel="stylesheet" href="enhancements.css"><link rel="stylesheet" href="theme.css"><script src="editor.js" type="module"></script></head><body class="editor-page">
<header class="site-header"><div class="container nav-wrap"><a href="./" class="wordmark">aniket<span>✳</span></a><nav aria-label="Editor navigation"><a href="./">← Back to portfolio</a></nav></div></header>
<main class="container editor-main"><p class="eyebrow">YOUR PORTFOLIO, YOUR WORK</p><h1>Keep your story current.</h1><p class="editor-intro">Add a client, update your role, or attach an Instagram profile or post. Save a draft to preview your changes on this browser, then export the file when you’re ready to update the hosted portfolio.</p>
<div class="editor-toolbar"><button id="save-draft" class="button primary" disabled>Save draft</button><a href="./?draft=1" class="button secondary" target="_blank" rel="noopener">Preview saved draft ↗</a><button id="export-data" class="button secondary" disabled>Export portfolio data ↓</button><button id="import-data" class="button secondary" disabled>Import data</button><input id="import-file" type="file" accept=".json,application/json" hidden></div>
<div class="editor-notice">Drafts stay in this browser and do not change the hosted website. To apply an update, export your data and share it in this conversation with “Update my portfolio.” Your site’s sharing settings stay unchanged.</div>
<p id="editor-status" class="editor-status" role="status" aria-live="polite">Loading your portfolio…</p>
<form id="editor-form"><section class="editor-section"><h2>Profile & contact</h2><div id="profile-fields" class="editor-fields"></div></section><section class="editor-section" id="client-editor"><div class="editor-layout-nav"><h2>Client projects</h2><a href="#add-project">+ Add another client</a></div><p class="editor-intro">Only include work and results you can explain. Use public content examples, not client conversations. Add one responsibility per line and one example link per line.</p><div id="editor-projects"></div><button type="button" id="add-project" class="button secondary editor-add" disabled>+ Add client project</button></section></form>
<p class="editor-footer-note">For a project link, paste an Instagram profile, /p/ post, or /reel/ URL. External links open in a new tab. For images, upload a work sample directly or use a public HTTPS image URL. No account connection is needed.</p>
<div class="editor-toolbar"><button id="restore-data" class="button secondary" disabled>Discard local draft</button></div>
</main></body></html>
```

## public/editor.js

```javascript
import { loadData, validateData, DRAFT_KEY, esc, safeImage } from './data.js';
let data, dirty=false;
const status=document.querySelector('#editor-status'),form=document.querySelector('#editor-form'),projectsEl=document.querySelector('#editor-projects');
function field(label,key,value,{wide=false,multiline=false,hint='',type='text'}={}) {
 return `<label class="field${wide?' wide':''}"><span>${esc(label)}</span>${multiline?`<textarea data-field="${esc(key)}">${esc(value)}</textarea>`:`<input type="${type}" data-field="${esc(key)}" value="${esc(value)}">`}${hint?`<small>${esc(hint)}</small>`:''}</label>`;
}
function projectForm(p,index) {
 return `<details class="editor-project" data-index="${index}"><summary>${esc(p.name)}</summary><div class="editor-fields">
 ${field('Client / project name','name',p.name)}${field('Industry / location','industry',p.industry)}
 ${field('Industry filter category','category',p.category)}${field('Platforms','platforms',(p.platforms||[]).join(', '),{hint:'Comma-separated, e.g. Instagram, Facebook.'})}${field('Target audience','audience',p.audience||'',{wide:true})}${field('Deliverables','deliverables',(p.deliverables||[]).join(', '),{wide:true,hint:'Comma-separated, e.g. Reel scripts, Content calendar.'})}${field('Project headline','headline',p.headline)}${field('Work types','formats',p.formats.join(', '),{hint:'Use comma-separated values: Strategy, Design, Copywriting, Reels, Community.'})}
 ${field('Short summary','summary',p.summary,{wide:true,multiline:true})}${field('Your role','role',p.role,{wide:true,multiline:true})}
 ${field('Responsibilities','responsibilities',p.responsibilities.join('\n'),{wide:true,multiline:true,hint:'One responsibility per line.'})}
 ${field('Your approach','approach',p.approach,{wide:true,multiline:true})}${field('Content example','example',p.example,{wide:true,multiline:true})}
 ${field('Example description','exampleType',p.exampleType,{hint:'For example: Reel hook from my work, or Illustrative concept.'})}
 <label class="field"><span>Preview style</span><select data-field="theme">${['clique','ascend','noah','refuge','pov','iron','eclipse','health','scholar','merge','property'].map(t=>`<option value="${t}"${p.theme===t?' selected':''}>${({clique:'Lavender',ascend:'Sage',noah:'Peach',refuge:'Forest',pov:'Slate',iron:'Blue',eclipse:'Apricot',health:'Mint',scholar:'Sky',merge:'Lilac',property:'Sand'})[t]}</option>`).join('')}</select></label>
 ${field('Instagram profile or post URL','instagram',p.instagram,{type:'url'})}${field('Client website URL','website',p.website,{type:'url'})}
 ${field('Additional examples','examples',p.examples.map(x=>`${x.label} | ${x.url}`).join('\n'),{wide:true,multiline:true,hint:'One per line: Reel example | https://www.instagram.com/reel/.../'})}
 <label class="field wide image-upload"><span>Upload a client image or work sample</span><input type="file" accept="image/jpeg,image/png,image/webp" data-upload="${index}"><small>JPG, PNG, or WebP, up to 10 MB. Added to your draft; export the file to include it in the hosted update.</small>${safeImage(p.image)?`<img class="upload-preview" src="${esc(safeImage(p.image))}" alt="Current client image or work sample">`:''}</label>
 ${field('Image URL or asset path (optional)','image',p.image,{hint:'An upload fills this field automatically. Clear it to use a designed text card.'})}${field('Image description','imageLabel',p.imageLabel)}
 <label class="field"><span>Image use</span><select data-field="imageKind"><option value="work"${p.imageKind!=='client'?' selected':''}>My work sample</option><option value="client"${p.imageKind==='client'?' selected':''}>Client profile photo / brand image</option></select></label>
 <label class="field"><span>Client image layout</span><select data-field="imageFit"><option value="cover"${p.imageFit!=='contain'?' selected':''}>Photo · fill the preview</option><option value="contain"${p.imageFit==='contain'?' selected':''}>Logo · show the whole image</option></select></label>
 <label class="field"><span>Photo focus</span><select data-field="imagePosition">${['top','center','bottom'].map(value=>`<option value="${value}"${(p.imagePosition||'center')===value?' selected':''}>${value[0].toUpperCase()+value.slice(1)}</option>`).join('')}</select><small>Applies to client photo previews.</small></label>
 ${field('Image source URL (optional)','imageSource',p.imageSource||'',{type:'url',hint:'For client photos or logos, link to the public source.'})}
 <button type="button" class="editor-remove" data-remove="${index}">Remove project from draft</button></div></details>`;
}
function render(openIndex=null) {
 document.querySelector('#profile-fields').innerHTML=field('Name','name',data.profile.name)+field('Location','location',data.profile.location)+field('Contact email','email',data.profile.email,{type:'email'})+field('LinkedIn URL (optional)','linkedin',data.profile.linkedin,{type:'url'})+field('Profile introduction','bio',data.profile.bio,{wide:true,multiline:true});
 projectsEl.innerHTML=data.projects.map(projectForm).join('');
 if(openIndex!==null) projectsEl.querySelector(`[data-index="${openIndex}"]`)?.setAttribute('open','');
}
function collect() {
 const result=structuredClone(data);
 document.querySelectorAll('#profile-fields [data-field]').forEach(el=>result.profile[el.dataset.field]=el.value.trim());
 projectsEl.querySelectorAll('[data-index]').forEach(panel=>{
 const p=result.projects[Number(panel.dataset.index)];
 panel.querySelectorAll('[data-field]').forEach(el=>{
 const key=el.dataset.field,value=el.value.trim();
 if(['formats','platforms','deliverables'].includes(key))p[key]=value.split(',').map(x=>x.trim()).filter(Boolean);
 else if(key==='responsibilities')p[key]=value.split('\n').map(x=>x.trim()).filter(Boolean);
 else if(key==='examples')p[key]=value.split('\n').filter(x=>x.trim()).map(line=>{const i=line.indexOf('|');if(i<0)throw new Error(`${p.name}: write example links as Label | https://...`);return {label:line.slice(0,i).trim(),url:line.slice(i+1).trim()}});
 else p[key]=value;
 });
 });
 return validateData(result);
}
function save() {
 data=collect();try{localStorage.setItem(DRAFT_KEY,JSON.stringify(data));}catch{throw new Error('This draft is too large for browser storage. Use fewer or smaller uploaded images.');}dirty=false;return data;
}
function showError(error){status.textContent=error.message;status.style.color='var(--error)';status.scrollIntoView({block:'nearest'});}
function notice(text){status.textContent=text;status.style.color='';}
form.addEventListener('submit',e=>e.preventDefault());
form.addEventListener('input',()=>{dirty=true;notice('Unsaved changes. Save a draft to preview them.');});
document.querySelector('#save-draft').addEventListener('click',()=>{try{save();notice('Draft saved on this browser. Open Preview saved draft to review it.');}catch(error){showError(error)}});
document.querySelector('#export-data').addEventListener('click',()=>{try{const output=save();const blob=new Blob([JSON.stringify(output,null,2)+'\n'],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='portfolio-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice('Exported portfolio-data.json. Share it in this conversation to update the hosted portfolio.');}catch(error){showError(error)}});
document.querySelector('#add-project').addEventListener('click',()=>{try{data=collect();data.projects.push({id:crypto.randomUUID(),name:'New client',industry:'Your industry',category:'',platforms:[],audience:'',deliverables:[],formats:['Design'],theme:'clique',headline:'Your next story.',summary:'',role:'',responsibilities:[],approach:'',exampleType:'Portfolio content example',example:'',image:'',imageLabel:'',instagram:'',website:'',examples:[]});render(data.projects.length-1);dirty=true;projectsEl.lastElementChild.scrollIntoView({behavior:'smooth',block:'start'});notice('New project added. Fill in the details and save your draft.');}catch(error){showError(error)}});
projectsEl.addEventListener('click',e=>{const button=e.target.closest('[data-remove]');if(!button)return;try{data=collect();const index=Number(button.dataset.remove);const name=data.projects[index].name;data.projects.splice(index,1);render();dirty=true;notice(`${name} removed from the unsaved draft. Hosted projects are unchanged.`);}catch(error){showError(error)}});
document.querySelector('#import-data').addEventListener('click',()=>document.querySelector('#import-file').click());
document.querySelector('#import-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>10_000_000)throw new Error('Choose a JSON data file smaller than 10 MB.');data=validateData(JSON.parse(await file.text()));render();dirty=true;notice('Data imported. Review the changes, then save your draft.');}catch(error){showError(error)}e.target.value='';});
document.querySelector('#restore-data').addEventListener('click',async()=>{try{if(!confirm('Discard the local draft and load the hosted portfolio data?'))return;localStorage.removeItem(DRAFT_KEY);data=await loadData(false);render();dirty=false;notice('Hosted portfolio data restored.');}catch(error){showError(error)}});
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
try{data=await loadData(true);render();document.querySelectorAll('button[disabled]').forEach(b=>b.disabled=false);notice(localStorage.getItem(DRAFT_KEY)?'Editing your saved local draft. Discard it to reload the latest hosted client list.':'Ready to edit. Save a draft before opening the preview.');}catch(error){showError(error)}

projectsEl.addEventListener('change',async e=>{
 const input=e.target.closest('[data-upload]');if(!input||!input.files[0])return;
 const file=input.files[0];
 try{
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Choose a JPG, PNG, or WebP image.');
  if(file.size>10000000)throw new Error('Choose an image smaller than 10 MB.');
  const bitmap=await createImageBitmap(file),ratio=Math.min(1,1200/Math.max(bitmap.width,bitmap.height));
  const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);
  const ctx=canvas.getContext('2d');ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();
  const image=canvas.toDataURL('image/webp',.85);if(!safeImage(image))throw new Error('This image is too large. Please choose a smaller image.');
  const panel=input.closest('[data-index]');panel.querySelector('[data-field="image"]').value=image;
  const description=panel.querySelector('[data-field="imageLabel"]');if(!description.value)description.value='Uploaded portfolio work sample';
  let preview=panel.querySelector('.upload-preview');if(!preview){preview=document.createElement('img');preview.className='upload-preview';preview.alt='Current client image or work sample';input.parentNode.append(preview);}preview.src=image;
  dirty=true;notice('Image added to your draft. Save and preview it, then export when ready.');
 }catch(error){showError(error)}input.value='';
});
```

## src/scene.js

```javascript
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

// Decorative, self-contained 3D. The portfolio stays usable without WebGL.
export function mountScene(host, motion) {
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' }); }
  catch { host.dataset.render = 'fallback'; return; }
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
  renderer.setClearColor(0x000000, 0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.35;
  renderer.domElement.setAttribute('aria-hidden', 'true');
  host.append(renderer.domElement);
  host.dataset.render = 'webgl';

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, .1, 30);
  camera.position.set(0, 0, 6.6);
  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room, .04);
  scene.environment = environment.texture;
  room.dispose(); pmrem.dispose();

  const group = new THREE.Group(); scene.add(group);
  const metal = new THREE.MeshPhysicalMaterial({ color: 0xd8d3ce, metalness: .88, roughness: .23, clearcoat: 1, clearcoatRoughness: .14, iridescence: .08, iridescenceIOR: 1.35, envMapIntensity: 1.8 });
  const knot = new THREE.Mesh(new THREE.TorusKnotGeometry(.86, .265, 176, 28, 2, 3), metal);
  knot.rotation.set(.34, -.4, -.45);
  knot.position.set(.25, .2, -.1);
  knot.scale.setScalar(1.17); group.add(knot);

  const pearl = new THREE.Mesh(new THREE.SphereGeometry(.22, 32, 24), new THREE.MeshPhysicalMaterial({color:0xff944d,metalness:.4,roughness:.12,clearcoat:1,envMapIntensity:1.7}));
  pearl.position.set(-1.32, 1.1, .1); group.add(pearl);
  const satellite = new THREE.Mesh(new THREE.IcosahedronGeometry(.26, 0), new THREE.MeshPhysicalMaterial({color:0xefebe4,metalness:.78,roughness:.19,envMapIntensity:2}));
  satellite.position.set(1.37, -1.35, .2); group.add(satellite);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.85,.008,8,140), new THREE.MeshBasicMaterial({color:0x37302b,transparent:true,opacity:.16}));
  ring.rotation.set(.7,.3,-.6);ring.position.z=-.5;group.add(ring);
  scene.add(new THREE.AmbientLight(0xffead7,.9));
  const light=new THREE.DirectionalLight(0xffffff,4);light.position.set(3,4,5);scene.add(light);
  const fill=new THREE.DirectionalLight(0xffac70,3);fill.position.set(-4,-2,2);scene.add(fill);

  let visible=true, frame=0, last=0, elapsed=0, targetX=0, targetY=0;
  function render() {renderer.render(scene,camera);}
  function resize() {const {width,height}=host.getBoundingClientRect();if(!width||!height)return;renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();render();}
  function loop(now) {
    frame=0;
    if(!motion.enabled||!visible||document.hidden)return;
    if(now-last>32) {
      const delta=Math.min((now-last)/1000,.05);last=now;elapsed+=delta;
      knot.rotation.y=-.4+elapsed*.09;
      knot.position.y=.2+Math.sin(elapsed*.55)*.08;
      pearl.position.y=1.1+Math.sin(elapsed*.8)*.1;
      satellite.rotation.y=elapsed*.25;satellite.rotation.z=elapsed*.12;
      group.rotation.x+=(targetY-group.rotation.x)*.06;
      group.rotation.y+=(targetX-group.rotation.y)*.06;
      render();
    }
    frame=requestAnimationFrame(loop);
  }
  function sync() {cancelAnimationFrame(frame);frame=0;last=performance.now();if(motion.enabled&&visible&&!document.hidden)frame=requestAnimationFrame(loop);else render();}
  const region=host.closest('.hero-art');
  region.addEventListener('pointermove',e=>{if(!motion.enabled||e.pointerType==='touch')return;const r=region.getBoundingClientRect();targetX=((e.clientX-r.left)/r.width-.5)*.4;targetY=((e.clientY-r.top)/r.height-.5)*.25;});
  region.addEventListener('pointerleave',()=>{targetX=targetY=0;});
  window.addEventListener('portfolio-motion',sync);
  document.addEventListener('visibilitychange',sync);
  const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();});observer.observe(host);
  const sizing=new ResizeObserver(resize);sizing.observe(host);
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();cancelAnimationFrame(frame);host.dataset.render='fallback';});
  resize();sync();
}
```

## public/assets/favicon.svg

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#ff792d"/><text x="32" y="46" font-family="Arial,sans-serif" font-size="52" font-weight="700" text-anchor="middle" fill="#111113">a</text></svg>
```
