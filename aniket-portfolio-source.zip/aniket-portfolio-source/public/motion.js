export const motion = {enabled: !matchMedia('(prefers-reduced-motion: reduce)').matches};
const pref=matchMedia('(prefers-reduced-motion: reduce)');
try{const saved=localStorage.getItem('aniket-motion');if(saved!==null)motion.enabled=saved==='on'&&!pref.matches;}catch{}
const toggle=document.querySelector('#motion-toggle');
function apply(){
  document.body.classList.toggle('motion-off',!motion.enabled);
  if(toggle){toggle.setAttribute('aria-pressed',String(motion.enabled));toggle.innerHTML=`<span aria-hidden="true">${motion.enabled?'Ⅱ':'▷'}</span> Motion ${motion.enabled?'on':'off'}`;}
  if(!motion.enabled)document.querySelectorAll('.project-card').forEach(c=>{c.style.removeProperty('--tilt-x');c.style.removeProperty('--tilt-y');});
  window.dispatchEvent(new Event('portfolio-motion'));
}
toggle?.addEventListener('click',()=>{motion.enabled=!motion.enabled;try{localStorage.setItem('aniket-motion',motion.enabled?'on':'off');}catch{}apply();});
pref.addEventListener('change',()=>{motion.enabled=!pref.matches;apply();});apply();

const grid=document.querySelector('#project-grid');
grid?.addEventListener('pointermove',e=>{
  const card=e.target.closest('.project-card');if(!card||!motion.enabled||e.pointerType==='touch')return;
  const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
  card.style.setProperty('--tilt-x',`${(y-.5)*-5}deg`);card.style.setProperty('--tilt-y',`${(x-.5)*6}deg`);
  card.style.setProperty('--shine-x',`${x*100}%`);card.style.setProperty('--shine-y',`${y*100}%`);
});
grid?.addEventListener('pointerout',e=>{const card=e.target.closest('.project-card');if(card&&!card.contains(e.relatedTarget)){card.style.removeProperty('--tilt-x');card.style.removeProperty('--tilt-y');}});
const progress=document.querySelector('#scroll-progress');
let ticking=false;
function updateProgress(){const max=document.documentElement.scrollHeight-innerHeight;if(progress)progress.style.transform=`scaleX(${max>0?scrollY/max:0})`;ticking=false;}
window.addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(updateProgress);}},{passive:true});

const host=document.querySelector('#scene-host');
if(host){import('./scene.js').then(({mountScene})=>mountScene(host,motion)).catch(()=>{host.dataset.render='fallback';});}
