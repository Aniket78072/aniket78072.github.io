# Content and assets

This portfolio represents Aniket's social media, writing and design work. Client profile links supply context and do not imply that Aniket authored every post on those accounts.

| Asset | Source/context |
| --- | --- |
| Nicholas G Photography team image | Public client website: https://www.nicholasgphotography.com/ |
| BodyClique logo | Public client website icon: https://bodyclique.com/apple-touch-icon.png |
| Noah Barks dog photograph | Public client website: https://noahbarks.com/ |
| Lisa Kasley Yoga photograph | Public client website: https://www.lisakasleyoga.com/ |
| Heavy Iron banner | Existing user-provided design included as a portfolio sample; no publication or campaign-result claim is made. |
| Hero sculpture | Code-generated decorative Three.js artwork; it is not a portrait of Aniket. |

Client imagery retains its respective ownership. Its inclusion here is for the existing portfolio's client context, not a grant of rights for unrelated use.

Three.js is distributed under the MIT licence. Its notice is included at `public/assets/three-LICENSE.txt`. The browser bundle includes the required Three.js code locally.

The displayed client list intentionally contains only Nicholas G Photography, Heavy Iron Inc., BodyClique, Noah Barks and Lisa Kasley Yoga. Lisa's detailed responsibilities and work samples remain blank until supplied. Unsupported follower-growth claims have been omitted.

Website source copied from deployed version 6, commit `d726bf3b4c35d0f6fb86c719719e2fb4e1a121b9`. This export adds local-run instructions and scripts without changing the front-end files.
