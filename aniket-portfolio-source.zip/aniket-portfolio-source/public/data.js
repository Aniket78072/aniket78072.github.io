export const DRAFT_KEY = 'aniket-portfolio-draft-v1';
export const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function safeUrl(value, instagram = false) {
  if (!value) return '';
  try {const u = new URL(value); if (u.protocol !== 'https:') return ''; if (instagram && !['instagram.com','www.instagram.com'].includes(u.hostname)) return ''; return u.href;} catch {return '';}
}
export function safeImage(value) {
  if (!value) return '';
  if (typeof value==='string' && value.length<1500000 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value)) return value;
  if (/^assets\/[a-zA-Z0-9_./-]+\.(jpg|jpeg|png|webp|svg)$/i.test(value) && !value.includes('..')) return value;
  return safeUrl(value);
}
export function validateData(data) {
  if (!data || !data.profile || typeof data.profile.name !== 'string' || !Array.isArray(data.projects)) throw new Error('Use a portfolio JSON file exported from this editor.');
  if (data.projects.length > 100) throw new Error('Please keep the portfolio under 100 projects.');
  const ids = new Set();
  for (const p of data.projects) {
    if (!p || typeof p.id !== 'string' || !p.id || ids.has(p.id) || typeof p.name !== 'string' || !p.name.trim()) throw new Error('Every project needs a unique ID and a client name.');
    ids.add(p.id);
    for(const key of ['platforms','deliverables']) if(p[key]!==undefined&&(!Array.isArray(p[key])||p[key].some(x=>typeof x!=='string'))) throw new Error(`${p.name}: ${key} must be a list of text.`);
    if(p.audience!==undefined&&typeof p.audience!=='string') throw new Error(`${p.name}: audience must be text.`);
    for (const key of ['formats','responsibilities','examples']) if (!Array.isArray(p[key])) throw new Error(`${p.name}: ${key} must be a list.`);
    if (p.formats.some(x=>typeof x !== 'string') || p.responsibilities.some(x=>typeof x !== 'string') || p.examples.some(x=>!x || typeof x.label !== 'string' || typeof x.url !== 'string')) throw new Error(`${p.name}: invalid project details.`);
    for(const key of ['industry','category','theme','headline','summary','role','approach','exampleType','example','image','imageLabel','instagram','website']) if (typeof p[key] !== 'string') throw new Error(`${p.name}: ${key} must be text.`);
    if(p.instagram && !safeUrl(p.instagram,true)) throw new Error(`${p.name}: enter a valid https Instagram profile or post URL.`);
    if(p.website && !safeUrl(p.website)) throw new Error(`${p.name}: enter a valid https website URL.`);
    if(p.examples.some(x=>!safeUrl(x.url))) throw new Error(`${p.name}: example links must use https.`);
    for(const [key,allowed] of Object.entries({imageKind:['','work','client'],imageFit:['','cover','contain'],imagePosition:['','top','center','bottom']})) if(p[key]!==undefined&&!allowed.includes(p[key])) throw new Error(`${p.name}: choose a valid ${key}.`);
    if(p.imageSource!==undefined&&(typeof p.imageSource!=='string'||(p.imageSource&&!safeUrl(p.imageSource)))) throw new Error(`${p.name}: image source must be an HTTPS URL.`);
    if(p.image && !safeImage(p.image)) throw new Error(`${p.name}: upload an image or use an assets path or HTTPS image URL.`);
  }
  if (data.profile.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.profile.email)) throw new Error('Enter a valid contact email.');
  if (data.profile.linkedin && !safeUrl(data.profile.linkedin)) throw new Error('Enter a valid https LinkedIn URL.');
  return data;
}
export async function loadData(draft = false) {
  if (draft) {try {const saved = localStorage.getItem(DRAFT_KEY); if(saved) return validateData(JSON.parse(saved));} catch(error) {console.warn('Draft could not load:',error.message);}}
  const response = await fetch('portfolio-data.json', {cache:'no-cache'});
  if(!response.ok) throw new Error('Could not load the portfolio. Please reload the page.');
  return validateData(await response.json());
}
