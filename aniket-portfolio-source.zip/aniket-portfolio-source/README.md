# Aniket's portfolio — complete source and setup guide

This is the complete front end from your live portfolio, version 6. It includes the light/orange theme, Social Media Executive hero, bundled 3D artwork, all five clients and images, Instagram links, project filters, email popup, and client editor.

Live portfolio: https://aniket-creative-portfolio.eleven7809.chatgpt.site

The `public/` and `src/` files match the deployed source. This download adds a local preview server, convenient npm commands, and instructions. It does not contain hosting credentials or change the live website.

## 1. Install Node.js

1. Go to https://nodejs.org/en/download.
2. Select the **LTS** release and your operating system. Use Node.js 22 or newer; the current LTS is suitable.
3. Install Node.js with npm included. On Windows, use the installer and its normal defaults. On macOS, use the installer. On Linux, follow the Linux installation instructions on that page.
4. If VS Code was open during installation, close and reopen it.

You only need to do this once. You do not need React, a database, API keys, a paid editor, or a VS Code extension to run this project.

## 2. Extract and open the project

1. Download `aniket-portfolio-source.zip`.
2. Extract the entire ZIP. On Windows: right-click → Extract All. On macOS: double-click the ZIP. On Linux: use your archive application's Extract action.
3. Open VS Code.
4. Choose **File → Open Folder** and select `aniket-portfolio-source`.
5. Check that you can see `package.json`, `public`, `src`, and `scripts` together in the Explorer. If you only see another folder with the same project name, open that inner folder.
6. Choose **Terminal → New Terminal**.

## 3. Check Node.js and npm

Enter these commands one at a time:

```bash
node --version
npm --version
```

Both should print a version number. If a command is not recognized, finish installing Node.js and reopen VS Code before trying again.

## 4. Start the website

In the terminal, run:

```bash
npm start
```

Open **http://localhost:4173** in your browser.

The terminal should also show these addresses:

| Page | Address |
| --- | --- |
| Portfolio | http://localhost:4173 |
| Client editor | http://localhost:4173/edit.html |
| Saved draft preview | http://localhost:4173/?draft=1 |

Keep the terminal running while you use the site. Press **Ctrl+C** in that terminal to stop it. Run `npm start` again whenever you want to reopen the local website.

**You can skip `npm install` for normal use.** The server uses built-in Node.js modules and the ready-to-run 3D bundle is already included. Installation is needed only if you want to rebuild the 3D source, as explained below.

Do not open `public/index.html` by double-clicking it. The portfolio loads JSON and JavaScript modules, so it needs the local HTTP server.

## 5. Edit client information without writing code

1. Open http://localhost:4173/edit.html.
2. Click a client name to expand its fields, or click **+ Add client project**.
3. Edit the client name, summary, your role, responsibilities, content examples, and links.
4. For Instagram, paste a complete HTTPS profile, post, or Reel URL.
5. Upload a JPG, PNG, or WebP image, or enter an asset path such as `assets/my-client.jpg`.
6. Choose **Client profile photo / brand image** for client imagery, or **My work sample** for your own work. This keeps the labels accurate.
7. Click **Save draft**.
8. Click **Preview saved draft** and check your changes.
9. Click **Export portfolio data** to download `portfolio-data.json`.
10. Move that downloaded file into the project's `public/` folder and replace the existing `portfolio-data.json`. Keep the name exactly `portfolio-data.json`, not `portfolio-data (1).json`.
11. Open the normal portfolio address, http://localhost:4173, and refresh. The updated file is now part of your local website.

The editor's Save button saves only in that browser. It does not write to your source files or publish online. Drafts belong to the exact browser/address used, so consistently use `localhost:4173` instead of switching between hostnames or ports. The main page shows drafts only when the address includes `?draft=1`.

The editor itself does not grant publishing access. Even on the public website, another visitor's saved draft stays in that visitor's browser.

If the editor keeps showing an old draft after you replace the JSON file, first export any draft you want to keep, then click **Discard local draft** to reload the data from the file served by your local server. Some existing interface messages say “hosted” or “share it in this conversation”; locally, you can apply the export by replacing `public/portfolio-data.json` as described above.

## 6. Edit the text, layout, and colours

Use **Ctrl+S** on Windows/Linux or **Cmd+S** on macOS to save your code changes, then refresh the browser. This preview server does not automatically refresh the page.

| What you want to change | Where to edit |
| --- | --- |
| Client entries, links, images, responsibilities and examples | `public/portfolio-data.json`, or use the editor |
| Name, profile bio, contact email and optional LinkedIn URL | `profile` inside `public/portfolio-data.json`, or use the editor |
| Visible hero title and introductory wording | `public/index.html` |
| The `1 year` experience note | `public/index.html` |
| Skills, tool names, employment and education text | `public/index.html` |
| Overall light/orange palette and most final styling | `public/theme.css` |
| Hero arrangement, sizing and orange semicircle | `public/hero.css` |
| Site tab title and social metadata | The `<head>` of `public/index.html` |
| Small browser-tab icon | `public/assets/favicon.svg` |
| 3D shape, lighting and materials | `src/scene.js`, followed by the rebuild command below |

For example, search for `hero-role` in `public/index.html`. The current title is:

```html
<p class="hero-role">A Social Media Executive <span>& Creative.</span></p>
```

The `profile.role` value in the JSON is retained as data, but the visible hero role is currently written in the HTML. Change the HTML to update what visitors see. Similarly, the hero location sentence and the navigation/footer wordmarks are written in the HTML.

The main colour variables start at the top of `public/theme.css`:

```css
:root {
  --bg: #fafaf8;
  --panel: #ffffff;
  --text: #171719;
  --brand-orange: #ff792d;
  --brand-peach: #ffb16f;
  --brand-soft: #fff0e4;
}
```

Edit the existing values there. Keep all five linked stylesheets in their existing order: `styles.css`, `enhancements.css`, `refinements.css`, `hero.css`, then `theme.css`. Later files override earlier styling; changing only the first stylesheet may have no visible effect.

## 7. Add images and Instagram examples

For a local image:

1. Put the image into `public/assets/`.
2. Use a simple filename, for example `new-client.jpg`.
3. Enter `assets/new-client.jpg` in that client's image field.
4. Add an accurate description in the image-description field.

Do not enter a path from your computer such as `C:\\Users\\Aniket\\Pictures\\photo.jpg`; visitors will not have access to that path. Asset paths begin at `public/`, so write `assets/new-client.jpg`, not `public/assets/new-client.jpg`.

The Instagram field supports a profile, post, or Reel URL. Additional examples use one line per link in the editor:

```text
Instagram profile | https://www.instagram.com/americanportra/
```

Replace the label and URL with the actual example you want to show. These are links; the site does not log in to Instagram or automatically fetch profile pictures. Client images are included as local assets.

If editing JSON by hand, copy an existing complete project object, give it a unique `id`, then replace its details. Keep required arrays such as `formats`, `responsibilities`, and `examples`, even when they are empty. JSON requires double quotes and cannot contain comments or trailing commas. Using the editor is easier for adding new entries.

## 8. Optional: change the 3D artwork

Skip this section to keep the current sculpture.

Install the development tools once:

```bash
npm install
```

Edit `src/scene.js`, then rebuild:

```bash
npm run build:3d
```

This uses Three.js and esbuild to replace `public/scene.js` with the new browser bundle. Refresh your browser to see the result. Edit `src/scene.js` rather than the generated, minified `public/scene.js`.

The existing animation has a motion toggle, respects reduced-motion preferences, and pauses when offscreen or the tab is hidden. Devices without usable WebGL display a static fallback.

## 9. Create and check a deployment folder

Run:

```bash
npm run build
```

This copies the contents of `public/` into `dist/`. After changing code or data, run it again before publishing.

To view the built folder locally, stop the development server with **Ctrl+C**, then run:

```bash
npm run preview
```

Open http://localhost:4173. This time the server reads `dist/` rather than `public/`.

For a generic static host, the build command is `npm run build` and the publish/output directory is `dist`. If uploading built files manually, upload the contents of `dist` so `index.html` is at the website root. The local preview server is only for your computer; it does not make a public website.

Your existing public Sites URL remains live independently. Editing this downloaded copy will not automatically update that URL. To update it through this conversation, send the exported JSON for content edits, or the revised project ZIP for code/image changes.

The source currently includes `noindex,nofollow` metadata. This does not stop people opening the public link, but it asks search engines not to index the page. If you choose to allow indexing in a future deployment, update the main page's robots metadata. Keep the editor page excluded from indexing. If you deploy at another domain, also update the `og:url` value in `public/index.html`.

## 10. Common problems

| Problem | Fix |
| --- | --- |
| `node` or `npm` is not recognized | Install Node.js with npm and restart VS Code. |
| `npm.ps1 cannot be loaded` on Windows | In VS Code's terminal menu, open **Command Prompt**, then run `npm start`; alternatively use `npm.cmd start`. No execution-policy change is needed. |
| `package.json` cannot be found | Open the extracted project folder containing `package.json`, then open a new terminal there. |
| Browser says the site cannot be reached | Start `npm start` and keep that terminal open. Use the address printed in the terminal. |
| Port 4173 is busy | Run `npm start -- --port 4175` and open http://localhost:4175. |
| Client cards are missing after a manual edit | Check `public/portfolio-data.json` for missing fields, trailing commas, or duplicate project IDs. The editor validates these for you. |
| A photo is missing | Check the filename and capitalisation, keep it under `public/assets/`, and use `assets/filename.jpg` in the image field. |
| Saved draft is not on the normal page | Export the JSON and replace `public/portfolio-data.json`, or open `/?draft=1` to inspect the saved draft. |
| Changes do not appear | Save, refresh, and confirm whether you are serving `public` or `dist`. For `dist`, rerun the build. Use a hard refresh if needed. |
| Preview says the build is missing | Run `npm run build` before `npm run preview`. |
| 3D is still or replaced by a static shape | Check the motion toggle and reduced-motion setting. The fallback also appears when WebGL is unavailable. The rest of the site remains usable. |

For a file-by-file explanation, open `FILE-GUIDE.md`. For the authored code collected by filename, open `SOURCE-CODE.md`. The actual editable files are also present individually.

Official Node.js download instructions: https://nodejs.org/en/download
