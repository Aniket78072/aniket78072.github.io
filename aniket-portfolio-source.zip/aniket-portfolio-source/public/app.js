import { loadData, esc, safeUrl, safeImage } from './data.js';
import './motion.js';
const grid=document.querySelector('#project-grid'),select=document.querySelector('#client-select'),category=document.querySelector('#category-select'),search=document.querySelector('#project-search'),dialog=document.querySelector('#project-dialog'),more=document.querySelector('#show-more');
let projects=[],activeFilter='All',expanded=false;
const themes=['iron','clique','ascend','noah','refuge','pov','eclipse','health','scholar','merge','property'];
function instagramLabel(url) {
  const safe=safeUrl(url,true);if(!safe)return 'Instagram';
  const parts=new URL(safe).pathname.split('/').filter(Boolean);
  return parts.length===1&&!['p','reel','reels','stories','explore'].includes(parts[0])?'@'+parts[0]:'Instagram';
}
function visual(p) {
  const theme=themes.includes(p.theme)?p.theme:'clique',img=safeImage(p.image);
  if(img&&p.imageKind==='client'){
    const position=['top','center','bottom'].includes(p.imagePosition)?p.imagePosition:'center';
    return `<div class="project-visual client-preview${p.imageFit==='contain'?' client-logo':''} focus-${position}"><img src="${esc(img)}" alt="${esc(p.imageLabel||p.name+' client image')}" loading="lazy"><span class="client-preview-label">CLIENT PROFILE</span>${p.imageFit==='contain'?`<strong class="client-preview-name">${esc(p.name)}</strong>`:''}<span class="client-preview-handle">${esc(instagramLabel(p.instagram))}</span></div>`;
  }
  if(img)return `<div class="project-visual theme-iron"><img src="${esc(img)}" alt="${esc(p.imageLabel||p.name+' work sample')}" loading="lazy"></div>`;
  return `<div class="project-visual theme-${theme}"><span class="visual-brand">${esc(p.name.toUpperCase())}</span><span class="visual-decoration" aria-hidden="true"></span><span class="visual-headline">${esc(p.headline)}</span><span class="visual-caption">${p.formats.length?esc(p.formats.slice(0,2).join(' / ').toUpperCase())+' · ':''}PORTFOLIO TREATMENT</span></div>`;
}
function link(url,label,instagram=false){const safe=safeUrl(url,instagram);return safe?`<a href="${esc(safe)}" target="_blank" rel="noopener noreferrer">${esc(label)} ↗</a>`:''}
function render() {
  const term=search.value.trim().toLowerCase();
  const filtered=projects.filter(p=>(activeFilter==='All'||p.formats.includes(activeFilter))&&(!select.value||p.id===select.value)&&(!category.value||p.category===category.value)&&(!term||[p.name,p.industry,p.summary,p.role,p.category,...p.formats,...(p.deliverables||[])].join(' ').toLowerCase().includes(term)));
  const limited=!expanded&&activeFilter==='All'&&!select.value&&!category.value&&!term;
  const shown=limited?filtered.slice(0,6):filtered;
  grid.innerHTML=shown.map(p=>`<article class="project-card"><button class="project-open" data-id="${esc(p.id)}" aria-label="Explore ${esc(p.name)}">${visual(p)}<div class="project-info"><div><h3>${esc(p.name)}</h3><p>${esc(p.industry)}</p></div><span class="open-arrow" aria-hidden="true">↗</span></div></button><div class="project-tags">${p.formats.map(f=>`<span>${esc(f)}</span>`).join('')}</div><p class="project-description">${esc(p.summary)}</p><div class="card-links">${link(p.instagram,instagramLabel(p.instagram),true)}${link(p.website,'Website')}${!p.instagram&&!p.website?'<span>Explore the project for work details</span>':''}</div></article>`).join('');
  document.querySelector('#result-count').textContent=`${String(shown.length).padStart(2,'0')}${shown.length<filtered.length?' of '+filtered.length:''} projects${activeFilter==='All'?'':' · '+activeFilter}`;
  document.querySelector('#empty-state').hidden=filtered.length>0;
  more.hidden=shown.length>=filtered.length;more.textContent=`Explore ${filtered.length-shown.length} more clients ↓`;
  document.querySelectorAll('.filter').forEach(b=>{const on=b.dataset.filter===activeFilter;b.classList.toggle('active',on);b.setAttribute('aria-pressed',on)});
}
function openProject(id) {
  const p=projects.find(p=>p.id===id);if(!p)return;
  const img=safeImage(p.image);
  const imageCaption=p.imageKind==='client'?`Client imagery${safeUrl(p.imageSource)?' · '+link(p.imageSource,'Image source'):''}`:`${esc(p.imageLabel)}. Portfolio creative; no claim of publication or campaign results.`;
  const facts=`<div class="dialog-facts"><div><h3>Industry & platforms</h3><p>${esc(p.category||p.industry)}${p.platforms?.length?'<br>'+p.platforms.map(esc).join(' · '):''}</p></div>${p.audience?`<div><h3>The audience</h3><p>${esc(p.audience)}</p></div>`:''}</div>`;
  const details=(p.role?`<div class="detail-block"><h3>My role</h3><p>${esc(p.role)}</p></div>`:'')+(p.responsibilities.length?`<div class="detail-block"><h3>Responsibilities</h3><ul>${p.responsibilities.map(r=>`<li>${esc(r)}</li>`).join('')}</ul></div>`:'')+(p.approach?`<div class="detail-block"><h3>The approach</h3><p>${esc(p.approach)}</p></div>`:'');
  document.querySelector('#dialog-content').innerHTML=`<div class="dialog-header"><p class="eyebrow">${esc(p.industry.toUpperCase())}</p><h2 id="dialog-title">${esc(p.name)}</h2><p>${esc(p.summary)}</p><div class="dialog-deliverables">${(p.deliverables||[]).map(x=>`<span>${esc(x)}</span>`).join('')}</div></div>${facts}<div class="dialog-body"><div>${details||'<div class="detail-block"><h3>Project details</h3><p>Details will be added alongside the work samples.</p></div>'}<div class="project-links">${link(p.instagram,'Instagram profile / post',true)}${link(p.website,'Client website')}${p.examples.map(e=>link(e.url,e.label)).join('')}</div>${p.instagram?'<p class="dialog-note">The profile link provides client context. It does not imply authorship of every post.</p>':''}</div><div>${p.example?`<div class="detail-block"><h3>Content example</h3><div class="sample-box">${esc(p.example)}</div><p class="sample-label">${esc(p.exampleType)} · reformatted for this portfolio.</p></div>`:!img?'<div class="sample-pending"><span aria-hidden="true">✳</span><h3>Work samples coming soon.</h3></div>':''}${img?`<img class="sample-image${p.imageKind==='client'&&p.imageFit==='contain'?' sample-logo':''}" src="${esc(img)}" alt="${esc(p.imageLabel||p.name+' work sample')}"><p class="sample-label">${imageCaption}</p>`:''}</div></div>`;
  dialog.showModal();dialog.scrollTop=0;
}
function reset(){activeFilter='All';select.value='';category.value='';search.value='';expanded=false;render()}
document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{activeFilter=b.dataset.filter;expanded=false;render()}));
select.addEventListener('change',render);category.addEventListener('change',render);search.addEventListener('input',render);
more.addEventListener('click',()=>{expanded=true;render();grid.querySelectorAll('.project-open')[6]?.focus({preventScroll:true})});
document.querySelector('#reset-filters').addEventListener('click',reset);
grid.addEventListener('click',event=>{const button=event.target.closest('[data-id]');if(button)openProject(button.dataset.id)});
document.querySelector('#client-ribbon').addEventListener('click',event=>{const b=event.target.closest('[data-project]');if(b)openProject(b.dataset.project)});
dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close()}});
const contactDialog=document.querySelector('#contact-dialog');
document.querySelectorAll('[data-contact]').forEach(button=>button.addEventListener('click',()=>{document.querySelector('#copy-status').textContent='';contactDialog.showModal()}));
contactDialog.querySelector('.dialog-close').addEventListener('click',()=>contactDialog.close());
contactDialog.addEventListener('click',event=>{if(event.target===contactDialog){const r=contactDialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)contactDialog.close()}});
document.querySelector('#copy-email').addEventListener('click',async()=>{
  const email=document.querySelector('#contact-email').textContent;
  try{await navigator.clipboard.writeText(email);document.querySelector('#copy-status').textContent='Email copied.'}
  catch{const selection=getSelection(),range=document.createRange();range.selectNodeContents(document.querySelector('#contact-email'));selection.removeAllRanges();selection.addRange(range);document.querySelector('#copy-status').textContent='Email selected. Use your device’s copy command.'}
});
try {
  const draft=new URLSearchParams(location.search).get('draft')==='1';document.querySelector('#draft-banner').hidden=!draft;
  const data=await loadData(draft);projects=data.projects;
  document.querySelectorAll('[data-name]').forEach(n=>n.textContent=data.profile.name);
  document.querySelectorAll('[data-location]').forEach(n=>n.textContent=data.profile.location||'');
  document.querySelector('[data-bio]').textContent=data.profile.bio||'';
  document.querySelectorAll('[data-email]').forEach(a=>a.href=`mailto:${encodeURIComponent(data.profile.email||'')}`);
  document.querySelector('#contact-email').textContent=data.profile.email||'aniketpathania68393@gmail.com';
  const linkedin=safeUrl(data.profile.linkedin);if(linkedin){const a=document.querySelector('#linkedin-link');a.href=linkedin;a.hidden=false}
  select.innerHTML='<option value="">All clients</option>'+projects.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  category.innerHTML='<option value="">All industries</option>'+[...new Set(projects.map(p=>p.category).filter(Boolean))].sort().map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
  document.querySelector('#total-count').textContent=String(projects.length).padStart(2,'0');document.querySelector('#client-total').textContent=projects.length;
  const featured=projects.slice(0,5);
  document.querySelector('#client-ribbon').innerHTML=featured.map(p=>`<button data-project="${esc(p.id)}">${esc(p.name)}</button>`).join('');
  render();
} catch(error){document.querySelector('#result-count').textContent=error.message;grid.innerHTML='<p>Project details are temporarily unavailable. Please reload this page.</p>';}
